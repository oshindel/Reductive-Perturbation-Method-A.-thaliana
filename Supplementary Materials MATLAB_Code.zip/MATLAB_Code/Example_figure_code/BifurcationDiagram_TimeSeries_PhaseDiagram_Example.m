% Locke2005a: Generate plot like Tokuda2019 Figure 1 - 01/31/2020
% kb = n_1;

clear
clc
warning('off','all')
addpath(genpath('../Code/Locke2005a'))

global foptions odeopts1...
    xsize...
    nval gval mval pval rval kval qval consv theta...
    critical system var norig index ce X0...
    L M N;

theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

index = 1; % [1,4] = [LHY mRNA, TOC1 mRNA];
xsize = 7; % system size.
[system,var] = Circadian_syms_Locke2005a();

Jacobian();
third_tensor();
fourth_tensor();

% Typical annealed solution parameter values:

nval = [7.5038, 0.6801];
gval = [1.4992, 3.0412];
mval = [10.0982, 1.9685, 3.7511, 2.3422, 7.2482, 1.8981, 1.2];
pval = [2.1994, 9.4440, 0.5];
rval = [0.2817, 0.7676, 0.4364, 7.3021];
kval = [3.8045, 5.3087, 4.1946, 2.5356, 1.4420, 4.8600, 1.2];
qval = [4.5703, 1];
consv = [1,2];

norig = nval;

%% Stuart-Landau parameters

% Find Bifurcation

mini = 0.9 * norig(1);
maxi = 1 * norig(1);
    
for i = 1:30

    bp = (maxi + mini) / 2;
    nval(1) = bp;
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});

    [~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
        pval, rval, kval, qval, consv, theta), [0 1e3], ones(1,xsize), odeopts1);
    X0 = X(end,:);
    
    [ce,~] = fsolve(systemFunc,X0,foptions);
    jacobian = Evaluation(L);
    jacobian = double(Evaluation_fp(jacobian));

    [~,ev,~] = eigen(jacobian);
    if real(ev(end)) > 0
        maxi = bp;
    else
        mini = bp;
    end

    if maxi - mini < 1e-4
        break
    end
    
end

critical = (maxi + mini) / 2;
mu_critical = critical / norig(1);

% Calculate sigma1 omega1

mucalc = -0.1:0.005:0.1;

nval = norig;
lambdas = zeros(size(mucalc));

for k = 1:length(mucalc)
%     nval(1) = critical - mucalc(k);
    nval(1) = critical + mucalc(k);
    [lambda,~] = Calc_lambdas();
    lambdas(k) = lambda;
end

n = 2; % highest degree of polyfit.
P = polyfit(mucalc,real(lambdas),n);
Q = polyfit(mucalc,imag(lambdas),n);
sigma_1 = P(n);
omega_1 = Q(n);

% Calculate g omega_0 eigenvectors

nval = norig;
nval(1) = critical;
L_0 = Evaluation(L);
M_0 = Evaluation(M);
N_0 = Evaluation(N);

ce = FixedPt();
L_0 = double(Evaluation_fp(L_0));
M_0 = double(Evaluation_fp(M_0));
N_0 = double(Evaluation_fp(N_0));

[revec,evalue,levec] = eigen(L_0);
% Values at criticality:
% revec = right eigenvectors; levec = left eigenvectors;
% eval = eigenvalues.

omega_0 = imag(evalue(end));
Ur = revec(:,end); % U: right eigenvector.
Ul = levec(:,end)'; % U-star: left eigenvector.
Ubr = revec(:,end-1); % U-bar: complex conjugate.

% Normalization:
Ur = Ur/(Ur(index));
Ubr = Ubr/(Ubr(index));
normalization = Ul * Ur;
Ul = Ul / normalization;

Ap = (2 * omega_0 * eye(xsize) * 1i - L_0)^(-1) * Mult(M_0,Ur) * Ur;
A0 = -2 * L_0^(-1) * Mult(M_0,Ur) * Ubr;

g = -2 * Ul * (Mult(M_0,Ur) * A0 + Mult(M_0,Ubr) * Ap)...
    - 3 * Ul * (Mult(Mult(N_0,Ur),Ur) * Ubr);

gp = real(g); % g-prime.
gpp = imag(g); % g-double-prime.

% Calculate R_s and omega_s

R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

%% Time series: LHY mRNA & TOC1 mRNA

% % ODE
% T1 = 1e4;
% [~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, norig, gval, mval,...
%     pval, rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
% X0 = X(end,:);
% [t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, norig, gval, mval,...
%     pval, rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);
% 
% startingPoint = find(X(:,1) == max(X(:,1)),1);
% Xshifted = X(startingPoint:end,:);
% tshifted = t(startingPoint:end) - t(startingPoint);
% 
% % Theory
% mu_normal = 1;
% ttheory = (0:0.001:336);
% 
% Xtheory = ce' + sqrt(mu_normal - mu_critical)...
%     .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal - mu_critical) * omega_s) * ttheory)...
%     + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal - mu_critical) * omega_s) * ttheory));

% ODE
T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, norig, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0:0.5:T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
[t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, norig, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0:0.5:T1], X0, odeopts1);

% [pks,lctn] = findpeaks(X(t<200,scaledby));
% startingPoint = lctn(4);
startingPoint = find(X(:,1) == max(X(:,1)),1);
tshifted = t(startingPoint:end) - t(startingPoint);
tshifted = tshifted(tshifted<101);
Xshifted = X(startingPoint:end,:);
Xshifted = Xshifted(tshifted<101,:);

% Theory
mu_normal = 1;
ttheory = (0:0.001:336);

[system,var] = Circadian_syms_Locke2005a();
System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

% epsilonSquared = (mu_critical - mu_normal) * norig(1) / critical;
epsilonSquared = mu_normal - mu_critical;
Xtheory = ce' + sqrt(epsilonSquared)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory));

% LHY mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,1),'.','b','SizeData',100)
plot(ttheory,Xtheory(1,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
axis([0 100 0.5 1.5])
title('Time Series DD-cycle')
xlabel('Time(Hours)')
ylabel('LHY mRNA (nM)')
legend('ODE','RPM')
plottools

% TOC1 mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,4),'.','b','SizeData',100)
plot(ttheory,Xtheory(4,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
axis([0 100 0.5 0.9])
title('Time Series DD-cycle')
xlabel('Time(Hours)')
ylabel('TOC1 mRNA (nM)')
legend('ODE','RPM')
plottools

%% Bifurcation Diagrams: parameter is n_1

% Simulation points

mu1 = 0.95:0.005:1.15;
xmaxs1 = zeros(size(mu1));
xmins1 = xmaxs1;
ces1 = xmaxs1;
freqs1 = xmaxs1;

T3 = 1e4;
for i = 1:length(mu1)
    
    nval(1) = mu1(i) * norig(1);
    if mu1(i) <= 1
        T2 = 1e5;
    else
        T2 = 1e4;
    end
    
    [~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
            pval, rval, kval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    
    [t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
            pval, rval, kval, qval, consv, theta), [0 T3], X0, odeopts1);
    
    [maximums,where] = findpeaks(X(:,index));
    xmaxs1(i) = mean(maximums);
    xmins1(i) = - mean(findpeaks(-X(:,index)));
    
    freqs1(i) = 1 / mean(diff(t(where)));
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);
    ces1(i) = ce(index);
    
end

% Theory curve: bifurcation diagram
mutheory = (0:0.001:0.5) + mu_critical;
amph = zeros(size(mutheory));
ampl = amph;

for i = 1:length(mutheory)
    
    nval(1) = mutheory(i) * norig(1);
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);

    amph(i) = ce(index) + sqrt(mutheory(i) - mu_critical) * R_s * 2;
    ampl(i) = ce(index) - sqrt(mutheory(i) - mu_critical) * R_s * 2;
    
end

freqtheory = (omega_0 + (mutheory - mu_critical) * omega_s) / (2*pi);
% freqtheory = (omega_0 - (mutheory - mu_critical) * omega_s) / (2*pi);

mus_stable = [mu1(mu1~=mu_critical) mu1(mu1~=mu_critical) mu1(mu1<=mu_critical)];
mus_unstable = mu1(mu1>mu_critical);
measurements_stable = [xmaxs1(mu1~=mu_critical) xmins1(mu1~=mu_critical) ces1(mu1<=mu_critical)];
measurements_unstable = ces1(mu1>mu_critical);
mutheories = [flip(mutheory) mutheory];
theory = [flip(ampl) amph];
figure(36);hold on;
scatter(mus_stable, measurements_stable,'.')
scatter(mus_unstable, measurements_unstable)
plot(mutheories, theory)
% y = 0:1;plot(mu_critical*ones(size(y)),y);
axis([0.95 1.15 0.4 1.8])
box on
title('Bifurcation Diagram (Amplitude) near Criticality','fontsize',14)
xlabel('Normalized LHY Transcription Rate','fontsize',14)
ylabel('LHY mRNA','fontsize',14)
legend('ODE: stable','ODE: unstable', 'RPM','Criticality')
plottools

figure(37);hold on
scatter(mu1(mu1>=mu_critical),freqs1(mu1>=mu_critical))
plot(mutheory,freqtheory)
% y = 0:1;plot(mu_critical*ones(size(y)),y);
axis([0.95 1.15 0.04 0.045])
box on
title('Bifurcation Diagram (Frequency) near Criticality')
xlabel('Normalized LHY Transcription Rate')
ylabel('Frequency of Oscillation')
legend('ODE','RPM','Criticality')
plottools

%% Check if the phase difference matches

mu_normal = 1;
nval = norig;

% ODE

T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
    pval, rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

[t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
    pval, rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);

begin = find(X(:,5) == max(X(:,5)));
t = t(begin:end) - t(begin);
X = X(begin:end,:);

% Theory

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

ttheory = (0:0.001:336);
Xtheory = ce' + sqrt(mu_normal)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal) * omega_s) * ttheory));

%% Produce Phase Diagram: LHYm (1) vs LHYc (2)

tpODE = 0:0.1:2*pi;
tp = 0:0.01:2*pi; % t-prime: arbitraty time

% ODE

[max1,peak1] = findpeaks(X(:,1));
[max2,peak2] = findpeaks(X(:,2));
deltaPhiODE = 2 * pi * (mean(t(peak1(1:400)) - t(peak2(1:400))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),1));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),2));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
LHYcODE = amp2ODE * cos(tpODE + deltaPhiODE);
% relAmpODE = LHYcODE/LHYmODE;

% Theory
U = Ur([1 2]);
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory = atan(b2/a2) - atan(b1/a1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(1)) * cos(tp);
LHYcTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,LHYcODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,LHYcTheory,'LineWidth',1.5)
axis equal
box on
title('LHYc vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('LHY Protein (nM)')
legend('ODE','RPM')
plottools

%% Produce Phase Diagram: TOC1m (4) vs TOC1c (5)

% ODE

[max1,peak1] = findpeaks(X(:,4));
[max2,peak2] = findpeaks(X(:,5));
deltaPhiODE = 2 * pi * (mean(t(peak1(1:400)) - t(peak2(1:400))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),4));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),5));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

TOC1mODE = amp1ODE * cos(tpODE);
TOC1cODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur([4 5]);
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory = atan(b2/a2) - atan(b1/a1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

TOC1mTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(1)) * cos(tp);
TOC1cTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(TOC1mODE,TOC1cODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(TOC1mTheory,TOC1cTheory,'LineWidth',1.5)
axis equal
box on
title('TOC1c vs TOC1m')
xlabel('{\it TOC1} mRNA (nM)')
ylabel('TOC1 Protein (nM)')
legend('ODE','RPM')
plottools

%% Produce Phase Diagram: LHYm (1) vs TOC1m (4)

% ODE

[max1,peak1] = findpeaks(X(:,1));
[max2,peak2] = findpeaks(X(:,4));
deltaPhiODE = 2 * pi * (mean(t(peak1(1:400)) - t(peak2(1:400))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),1));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),4));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
TOC1mODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur([1 4]);
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory = atan(b2/a2) - atan(b1/a1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(1)) * cos(tp);
TOC1mTheory = 2 * R_s * sqrt(mu_normal-mu_critical) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,TOC1mODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,TOC1mTheory,'LineWidth',1.5)
axis equal
box on
title('TOC1m vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('{\itTOC1| mRNA (nM)')
legend('ODE','RPM')
plottools
