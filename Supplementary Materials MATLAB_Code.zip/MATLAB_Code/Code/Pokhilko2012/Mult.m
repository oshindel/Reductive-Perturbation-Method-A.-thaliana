% Tensor and vector multiplication

% A is a tensor; B is a vector.  Mult compress A into C along the last
% dimension.

function C = Mult(A,B)

    k = size(A);
    csize = k;
    csize(end) = 1;
    C = zeros(csize);
    temp = C;
    index = 1;
    s = prod(csize);
    
    for i = 1:k(end)
        for j = index:index + s - 1
            temp(j - s*(i-1)) = A(j);
        end
        C = C + B(i) * temp;
        index = index + s;
    end
    
end
