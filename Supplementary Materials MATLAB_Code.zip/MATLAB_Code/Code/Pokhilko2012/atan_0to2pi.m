function [angle] = atan_0to2pi(a,b)
% take arctan of b/a, but shift the range to 0 to 2pi

angle = atan(b/a);

if angle >= 0
    if a<0
        angle = angle + pi;
    end
end
if angle < 0
    if a < 0
        angle = angle + pi;
    else
        angle = 2*pi - angle;
    end
end

end

