% Substitute in values for symbolic expressions: parameter values

% Pokhilko 2012

function x = Evaluation(x0)

    global theta nval gval mval pval qval consv;

    n = sym('n', [1 length(nval)]);
    g = sym('g', [1 length(gval)]);
    m = sym('m', [1 length(mval)]);
    p = sym('p', [1 length(pval)]);
    cons = sym('cons', [1 length(consv)]);
    syms sun;
    
    x = subs(x0,n,nval);
    x = subs(x,g,gval);
    x = subs(x,m,mval);
    x = subs(x,p,pval);
    x = subs(x,cons,consv);
    x = subs(x,sun,theta);
    
    if theta ~= 0
        q = sym('q', [1 length(qval)]);
        x = subs(x,q,qval);
    end
    
end
