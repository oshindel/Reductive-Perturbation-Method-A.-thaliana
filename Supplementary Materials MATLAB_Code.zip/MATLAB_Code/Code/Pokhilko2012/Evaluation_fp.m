% Substitute in values for symbolic expressions: Fixed point

function var = Evaluation_fp(var0)

    global xsize ce;
    
    x = sym('x', [1 xsize]);
    var = subs(var0,x,ce);
    
end
