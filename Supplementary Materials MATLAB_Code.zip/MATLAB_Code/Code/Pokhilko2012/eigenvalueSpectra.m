% Generate the eigenvalue spectra of all degradation rates rangin 0 to
% biological value in paper.

global foptions odeopts1...
    xsize nval gval mval pval qval consv ...
    system var morig ce X0 L;

% ind = 9; % the assumed bifurcation parameter in m
theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

%% Pokhilko2012
xsize = 28; % system size.

qval = [1, 1.56, 2.8];
nval = [2.6, 0.64, 0.29, 0.07, 0.23, 20, 0.2, 0.5, 0.2, 0.4,...
    0.6, 12.5, 1.3, 0.1];
gval = [0.1, 0.01, 0.6, 0.01, 0.15, 0.3, 0.6, 0.01, 0.3, 0.5,...
    0.7, 0.2, 1, 0.004, 0.4, 0.3];
mval = [0.54, 0.24, 0.2, 0.2, 0.3, 0.3, 0.70, 0.4, 1.1, 1,...
    1, 1, 0.32, 0.4, 0.7, 0.5, 0.5, 3.4, 0.2, 0.6,...
    0.08, 0.1, 1.8, 0.1, 1.8, 0.5, 0.1, 20, 5, 3,...
    0.3, 0.2, 13, 0.6, 0.3, 0.1, 0.8, 0.5, 0.3];
pval = [0.13, 0.27, 0.1, 0.56, 4, 0.6, 0.3, 0.6, 0.8, 0.54,...
    0.51, 3.4, 0.1, 0.14, 3, 0.62, 4.8, 4, 1, 0.1,...
    1, 0.5, 0.37, 10, 8, 0.3, 0.8, 2, 0.1, 0.9,...
    0.1];
consv = [2, 2, 2, 2, 2, 2];

morig = mval;

for j = 1:length(morig)
    
    ind = j;
%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Pokhilko2012();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Pokhilko2012(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
X0 = real(X0);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%%

mu = 0.01:0.01:1;
eigenvalue = zeros(xsize,length(mu));
for i = 1:length(mu)
    mval(ind) = morig(ind) * mu(i);
    L_0 = Evaluation(L);
    ce = FixedPt();
    L_0 = double(Evaluation_fp(L_0));
    [revec,evalue,levec] = eigen(L_0);
    eigenvalue(:,i) = evalue;
end

figure
title("m"+ j)
hold on
for i = 1:xsize
    scatter(real(eigenvalue(i,:)),imag(eigenvalue(i,:)));
end
plottools

end