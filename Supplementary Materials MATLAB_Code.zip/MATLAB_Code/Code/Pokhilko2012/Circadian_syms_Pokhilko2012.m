% Differential Equations of Circadian Cycle: Symbolic

% Pokhilko 2012

% 1 = c_L^m;        2 = c_L;            3 = c_{L mod};      4 = c_P;
% 5 = c_{P9}^m;     6 = c_{P9};         7 = c_{P7}^m;       8 = c_{P7};
% 9 = c_{NI}^m;     10 = c_{NI};        11 = c_T^m;         12 = c_T;
% 13 = c_{E4}^m;    14 = c_{E4};
% 15 = c_{E3}^m;    16 = c_{E3}^c;      17 = c_{E3}^n;
% 18 = c_{LUX}^m;   19 = c_{LUX};
% 20 = c_{COP1}^c;  21 = c_{COP1}^n;    22 = c_{COP1}^d;
% 23 = c_{EG}^c;    24 = c_{EC};        25 = c_{ZTL};       26 = c_{ZG};
% 27 = c_{G}^m;     28 = c_{G}^c;

function [dxdt,x] = Circadian_syms_Pokhilko2012()

    global xsize;

    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 14]);
    g = sym('g', [1 16]);
    m = sym('m', [1 39]);
    p = sym('p', [1 31]);
    q = sym('q', [1 3]);
    cons = sym('cons', [1 6]);
    
    syms sun;
    dark = 1 - sun;

    % Recurring expressions:
    c_E34 = p(25) * x(14) * x(17) / (p(26) * x(19) + p(21) + m(37) * x(22) + m(36) * x(21));
    c_Gn = p(28) * x(28) / (p(29) + m(19) + p(17) * x(17));
    c_EGn = (p(18) * x(23) + p(17) * x(17) * c_Gn) / (m(9) * x(21) + m(10) * x(22) + p(31));
    c_Gntot = c_Gn + c_EGn;
    c_Ltot = x(2) + x(3);
    
    % Differential equations:
    dxdt(1) = q(1) * sun * x(4) + n(1) * g(1)^cons(1) / (g(1)^cons(1)...
        + (x(6) + x(8) + x(10) + x(12))^cons(1)) - (m(1) * sun + m(2) * dark) * x(1);
    dxdt(2) = (p(2) + p(1) * sun) * x(1) - m(3) * x(2)...
        - p(3) * x(2)^cons(3) / (x(2)^cons(3) + g(3)^cons(3));
    dxdt(3) = p(3) * x(2)^cons(3) / (x(2)^cons(3) + g(3)^cons(3)) - m(4) * x(3);
    dxdt(4) = p(7) * dark * (1 - x(4)) - m(11) * x(4) * sun;
    dxdt(5) = sun * q(3) * x(4) + (g(8) / (g(8) + x(24))) * (n(4) + n(7)...
        * x(2)^cons(5) / (g(9)^cons(5) + x(2)^cons(5))) - m(12) * x(5);
    dxdt(6) = p(8) * x(5) - (m(13) + m(22) * dark) * x(6);
    dxdt(7) = n(8) * c_Ltot^cons(5) / (g(10)^cons(5) + c_Ltot^cons(5))...
        + n(9) * x(6)^cons(6) / (g(11)^cons(6) + x(6)^cons(6)) - m(14) * x(7);
    dxdt(8) = p(9) * x(7) - (m(15) + m(23) * dark) * x(8);
    dxdt(9) = n(10) * x(3)^cons(5) / (g(12)^cons(5) + x(3)^cons(5))...
        + n(11) * x(8)^cons(2) / (g(13)^cons(2) + x(8)^cons(2)) - m(16) * x(9);
    dxdt(10) = p(10) * x(9) - (m(17) + m(24) * dark) * x(10);
    dxdt(11) = n(2) * (g(4) / (g(4) + x(24))) * (g(5)^cons(5)...
        / (g(5)^cons(5) + x(2)^cons(5))) - m(5) * x(11);
    dxdt(12) = p(4) * x(11) - (m(6) + m(7) * dark) * x(12) * (x(25) * p(5) + x(26))...
        - m(8) * x(12);
    dxdt(13) = n(13) * (g(2) / (g(2) + x(24))) * (g(6)^cons(5)...
        / (g(6)^cons(5) + x(2)^cons(5))) - m(34) * x(13);
    dxdt(14) = p(23) * x(13) - m(35) * x(14) - p(25) * x(14) * x(17) + p(21) * c_E34;
    dxdt(15) = n(3) * g(16)^cons(5) / (g(16)^cons(5) + x(2)^cons(5)) - m(26) * x(15);
    dxdt(16) = p(16) * x(15) - m(9) * x(16) * x(20) - p(17) * x(16) * x(28)...
        - p(19) * x(16) + p(20) * x(17);
    dxdt(17) = p(19) * x(16) - p(20) * x(17) - p(17) * x(17) * c_Gn - m(30) * x(17) * x(22)...
        - m(29) * x(17) * x(21) + p(21) * c_E34 - p(25) * x(14) * x(17);
    dxdt(18) = n(13) * (g(2) / (g(2) + x(24))) * (g(6)^cons(5)...
        / (g(6)^cons(5) + x(2)^cons(5))) - m(34) * x(18);
    dxdt(19) = p(27) * x(18) - m(39) * x(19) - p(26) * x(19) * c_E34;
    dxdt(20) = n(5) - p(6) * x(20) - m(27) * x(20) * (1 + p(15) * sun);
    dxdt(21) = p(6) * x(20) - n(6) * sun * x(4) * x(21) - n(14) * x(21)...
        - m(27) * x(21) * (1 + p(15) * sun);
    dxdt(22) = n(14) * x(21) + n(6) * sun * x(4) * x(21) - m(31) * (1 + m(33) * dark) * x(22);
    dxdt(23) = p(17) * x(16) * x(28) - m(9) * x(23) * x(20) - p(18) * x(23) + p(31) * c_EGn;
    dxdt(24) = p(26) * x(19) * c_E34 - m(36) * x(24) * x(21) - m(37) * x(24) * x(22)...
        - m(32) * x(24) * (1 + p(24) * sun * c_Gntot^cons(4) / (g(7)^cons(4) + c_Gntot^cons(4)));
    dxdt(25) = p(14) - p(12) * sun * x(25) * x(28) + p(13) * x(26) * dark - m(20) * x(25);
    dxdt(26) = p(12) * sun * x(25) * x(28) - p(13) * x(26) * dark - m(21) * x(26);
    dxdt(27) = sun * q(2) * x(4) + n(12) * (g(14) / (g(14) + x(24)))...
        * (g(15)^cons(5) / (g(15)^cons(5) + x(2)^cons(5))) - m(18) * x(27);
    dxdt(28) = p(11) * x(27) - p(12) * sun * x(25) * x(28) + p(13) * x(26) * dark...
        - m(19) * x(28) - p(17) * x(16) * x(28) - p(28) * x(28) + p(29) * c_Gn;
    
end
