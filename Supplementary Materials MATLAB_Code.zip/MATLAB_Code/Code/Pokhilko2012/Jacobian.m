% Jacobian matrix

function [] = Jacobian()

    global xsize system var L;
    L = sym('l', [xsize xsize]);
    
    for j = 1:xsize
        L(:,j) = diff(system,var(j));
    end
   
end
