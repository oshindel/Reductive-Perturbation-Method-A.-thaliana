% Pokhilko2012: Generate plot like Tokuda2019 Figure 1

clear; clc
warning('off','all')
load('../../Data/FInalData.mat')

global foptions odeopts1...
    xsize...
    nval gval mval pval qval consv theta...
    critical system var morig index ce X0;

foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

%% Define input values

theta = 1;
qval = [1, 1.56, 2.8];
nval = [2.6, 0.64, 0.29, 0.07, 0.23, 20, 0.2, 0.5, 0.2, 0.4,...
    0.6, 12.5, 1.3, 0.1];
gval = [0.1, 0.01, 0.6, 0.01, 0.15, 0.3, 0.6, 0.01, 0.3, 0.5,...
    0.7, 0.2, 1, 0.004, 0.4, 0.3];
mval = [0.54, 0.24, 0.2, 0.2, 0.3, 0.3, 0.70, 0.4, 1.1, 1,...
    1, 1, 0.32, 0.4, 0.7, 0.5, 0.5, 3.4, 0.2, 0.6,...
    0.08, 0.1, 1.8, 0.1, 1.8, 0.5, 0.1, 20, 5, 3,...
    0.3, 0.2, 13, 0.6, 0.3, 0.1, 0.8, 0.5, 0.3];
pval = [0.13, 0.27, 0.1, 0.56, 4, 0.6, 0.3, 0.6, 0.8, 0.54,...
    0.51, 3.4, 0.1, 0.14, 3, 0.62, 4.8, 4, 1, 0.1,...
    1, 0.5, 0.37, 10, 8, 0.3, 0.8, 2, 0.1, 0.9,...
    0.1];
consv = [2, 2, 2, 2, 2, 2];

morig = mval;

index = 1; % [1,4] = [LHY mRNA, TOC1 mRNA];
xsize = 28; % system size.
modelNum = 5;

%% Stuart-Langau parameters

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
critical = criticalValues(modelNum);
mu_critical = critical / morig(bp);
sigma_1 = real(Lambda1);
omega_1 = imag(Lambda1);
g = G(modelNum);
gp = real(g); % g-prime.
gpp = imag(g); % g-double-prime.
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);

R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);

%% Time series: LHY mRNA & TOC1 mRNA

% ODE
T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Pokhilko2012(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
[t,X] = ode15s(@(t,X)Circadian_Pokhilko2012(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], X0, odeopts1);

[pks,lctn] = findpeaks(X(t<200,scaledby));
startingPoint = lctn(4);
tshifted = t(startingPoint:end) - t(startingPoint);
tshifted = tshifted(tshifted<101);
Xshifted = X(startingPoint:end,:);
Xshifted = Xshifted(tshifted<101,:);

% Theory
mu_normal = 1;
ttheory = (0:0.001:101);

[system,var] = Circadian_syms_Pokhilko2012();
System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

epsilonSquared = (mu_critical - mu_normal) * morig(bp) / critical;
Xtheory = ce' + sqrt(epsilonSquared)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory));

% LHY mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,1),'.','b','SizeData',45)
plot(ttheory,Xtheory(1,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
title('Pokhilko2012 LL-cycle','fontsize',14)
xlabel('Time (hr)','fontsize',14)
ylabel('{\it LHY} mRNA (nM)','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools

% TOC1 mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,11),'.','b','SizeData',45)
plot(ttheory,Xtheory(11,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
title('Pokhilko2012 LL-cycle','fontsize',14)
xlabel('Time (hr)','fontsize',14)
ylabel('{\it TOC1} mRNA (nM)','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools

%% Bifurcation Diagrams

% Simulation points

mu1 = 0.8:0.05:ceil(mu_critical);
xmaxs1 = zeros(size(mu1));
xmins1 = xmaxs1;
ces1 = xmaxs1;
freqs1 = xmaxs1;

for i = 1:length(mu1)
    
    mval(bp) = mu1(i) * morig(bp);
    if mu1(i) <= mu_critical+0.1 && mu1(i) >= mu_critical-0.1
        T2 = 1e5;
    else
        T2 = 1e4;
    end
    
    [~,X] = ode15s(@(t,X)Circadian_Pokhilko2012(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    
    [t,X] = ode15s(@(t,X)Circadian_Pokhilko2012(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], X0, odeopts1);
    
    [maximums,where] = findpeaks(X(:,index));
    xmaxs1(i) = mean(maximums);
    xmins1(i) = - mean(findpeaks(-X(:,index)));
    
    freqs1(i) = 1 / mean(diff(t(where)));
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);
    ces1(i) = ce(index);
    
end

% Theory curve: bifurcation diagram
mutheory = mu1(1):0.001:mu_critical;
amph = zeros(size(mutheory));
ampl = amph;

for i = 1:length(mutheory)
    
    mval(bp) = mutheory(i) * morig(bp);
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);

    epsilonSquared = (mu_critical - mutheory(i)) * morig(bp) / critical;
    XRPM = ce' + sqrt(epsilonSquared)...
        .* (Ur .* R_s .* exp(1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory)...
        + Ubr .* R_s .* exp(-1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory));
    amph(i) = max(XRPM(index,:));
    ampl(i) = min(XRPM(index,:));
    
end

epsilonSquared = (mu_critical - mutheory) * morig(bp) / critical;
freqtheory = (omega_0 + (epsilonSquared) * omega_s) / (2*pi);

mus_stable = [mu1(mu1<=mu_critical) mu1(mu1<=mu_critical) mu1(mu1>=mu_critical)];
mus_unstable = mu1(mu1<mu_critical);
measurements_stable = [xmaxs1(mu1<=mu_critical) xmins1(mu1<=mu_critical) ces1(mu1>=mu_critical)];
measurements_unstable = ces1(mu1<mu_critical);
mutheories = [mutheory flip(mutheory)];
theory = [ampl flip(amph)];
figure;hold on;
scatter(mus_stable, measurements_stable,'o','b','filled')
scatter(mus_unstable, measurements_unstable,'o','b')
plot(mutheories, theory,'LineWidth',2,'Color',[0.8500 0.3250 0.0980])
box on
title('Pokhilko2012 Amplitude near Criticality','fontsize',14)
xlabel('Normalized Degradation Rate','fontsize',14)
ylabel('{\it LHY} mRNA','fontsize',14)
legend({'Stable','Unstable', 'RPM'},'fontsize',14)
plottools

figure;hold on
scatter(mu1(mu1<=mu_critical),freqs1(mu1<=mu_critical),'x','b','SizeData',45,'LineWidth',1.5)
plot(mutheory,freqtheory,'LineWidth',2,'Color',[0.8500 0.3250 0.0980])
box on
title('Pokhilko2012 Frequency near Criticality','fontsize',14)
xlabel('Normalized Degradation Rate','fontsize',14)
ylabel('Frequency (hr^{-1})','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools
