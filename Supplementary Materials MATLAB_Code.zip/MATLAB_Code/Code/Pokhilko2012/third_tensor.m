% 3rd-order tensor

function [] = third_tensor()

    global L M xsize var;
    M = sym('l', [xsize xsize xsize]);
    
    for k = 1:xsize
        M(:,:,k) = diff(L,var(k));
    end
    
    M = (1/2) * M;
    
end