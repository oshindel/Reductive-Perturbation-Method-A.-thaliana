% 4rd-order tensor

function [] = fourth_tensor()
    
    global M N xsize var;
    N = sym('l', [xsize xsize xsize xsize]);

    for l = 1:xsize
        N(:,:,:,l) = diff(M,var(l));
    end
    
    N = (1/3) * N; % M is already mixed partials divided by 2 factorial.
    
end