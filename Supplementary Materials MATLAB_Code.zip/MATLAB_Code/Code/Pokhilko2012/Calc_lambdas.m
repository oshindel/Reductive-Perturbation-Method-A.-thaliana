% Calculate two lambdas with largest real parts:
% lambda1 is the eigenvalue with the largest real part

function [lambda1, lambda2] = Calc_lambdas()

    global L ce;
    Lmu = Evaluation(L);
    ce = FixedPt();
    Lmu = double(Evaluation_fp(Lmu));
    [~,ev,~] = eigen(Lmu);
    lambda1 = ev(end);
    lambda2 = ev(end - 1);
    
end
