% Find fixed points

function fp = FixedPt()

    global system var foptions ce
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});

    [fp,~] = fsolve(systemFunc,ce,foptions);

end

