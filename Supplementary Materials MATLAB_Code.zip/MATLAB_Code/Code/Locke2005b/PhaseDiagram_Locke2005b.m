% Locke 2005b: Produce Phase Diagrams
% (check phase relationships (varying m_1))

clear; clc
load('../../Data/FInalData.mat')
warning('off','all')

global foptions odeopts1...
    xsize...
    nval gval mval pval rval kval qval consv theta...
    critical system var morig index ce X0;

theta = 1;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

nval = [5.1694, 3.0087, 0.2431, 0.0857, 0.1649];
gval = [0.876738488, 0.036805783, 0.26593318, 0.538811228, 1.17803247, 0.064455137];
mval = [1.5283, 20.4400, 3.6888, 3.8231, 0.0013, 3.1741, 0.0492, 4.0424,...
    10.1132, 0.2179, 3.3442, 4.2970, 0.1347, 0.6114, 1.2];
pval = [0.8295, 4.3240, 2.1470, 0.2485, 0.5];
rval = [16.8363, 0.1687, 0.3166, 2.1509, 1.0352, 3.3017, 2.2123, 0.2002];
kval = [1.8170, 1.5644, 1.2765, 2.5734, 2.7454, 0.4033, 6.5585, 0.6632,...
    17.1111, 1.7303, 1.8258, 1.8066, 1.2];
qval = [2.4514, 2.40178, 1];
consv = [3.3064, 1.0258, 1.0258, 1.4422, 3.6064, 1.0237];

morig = mval;

index = [1,2,4,5]; % = [LHY mRNA, LHY protein(c), TOC1 mRNA,TOC1 protein(c)];
xsize = 13; % system size.
modelNum = 2;
[system,var] = Circadian_syms_Locke2005b();

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);
g = G(modelNum);
gp = real(g);
gpp = imag(g);
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);
critical = criticalValues(modelNum);

mu_normal = (critical - (morig(bp))) / critical;

%% Generate signals
% ODE

T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

[t,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);
begin = find(X(:,scaledby) == max(X(:,scaledby)));
t = t(begin(1):end) - t(begin(1));
X = real(X(begin(1):end,:));

% Theory

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

ttheory = (0:0.001:336);
Xtheory = ce' + sqrt(mu_normal)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal) * omega_s) * ttheory));

%% Produce Phase Diagram: LHYm vs LHYc

tpODE = 0:0.1:2*pi;
tp = 0:0.01:2*pi; % t-prime: arbitraty time

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(2)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(2)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
LHYcODE = amp2ODE * cos(tpODE + deltaPhiODE);
% relAmpODE = LHYcODE/LHYmODE;

% Theory
U = Ur(index([1 2]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
LHYcTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,LHYcODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,LHYcTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005b LHYc vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('LHY Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: TOC1m vs TOC1c

% ODE

[max1,peak1] = findpeaks(X(:,index(3)));
[max2,peak2] = findpeaks(X(:,index(4)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(3)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(4)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

TOC1mODE = amp1ODE * cos(tpODE);
TOC1cODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([3 4]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1cTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(TOC1mODE,TOC1cODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(TOC1mTheory,TOC1cTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005b TOC1c vs TOC1m')
xlabel('{\it TOC1} mRNA (nM)')
ylabel('TOC1 Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: LHYm vs TOC1m

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(3)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(3)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
TOC1mODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([1 3]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,TOC1mODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,TOC1mTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005b TOC1m vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('{\it TOC1} mRNA (nM)')
legend('ODE','RPM','fontsize',14)
plottools


