% Main file for simulation: Locke 2005b

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    nval gval mval pval rval kval qval consv mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 13; % system size.

nval = [5.1694, 3.0087, 0.2431, 0.0857, 0.1649];
gval = [0.876738488, 0.036805783, 0.26593318, 0.538811228, 1.17803247, 0.064455137];
mval = [1.5283, 20.4400, 3.6888, 3.8231, 0.0013, 3.1741, 0.0492, 4.0424,...
    10.1132, 0.2179, 3.3442, 4.2970, 0.1347, 0.6114, 1.2];
pval = [0.8295, 4.3240, 2.1470, 0.2485, 0.5];
rval = [16.8363, 0.1687, 0.3166, 2.1509, 1.0352, 3.3017, 2.2123, 0.2002];
kval = [1.8170, 1.5644, 1.2765, 2.5734, 2.7454, 0.4033, 6.5585, 0.6632,...
    17.1111, 1.7303, 1.8258, 1.8066, 1.2];
qval = [2.4514, 2.40178, 1];
consv = [3.3064, 1.0258, 1.0258, 1.4422, 3.6064, 1.0237];

morig = mval;
disp('Locke 2005b')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Locke2005b();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [t,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
            rval, kval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Locke2005b
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end

end
disp('Bifurcation parameter:'); disp(bifpara)
