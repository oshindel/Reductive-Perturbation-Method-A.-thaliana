% Substitute in values for symbolic expressions: parameter values

% Locke 2005b

function x = Evaluation(x0)

    global theta nval gval mval pval rval kval qval consv;

    n = sym('n', [1 length(nval)]);
    g = sym('g', [1 length(gval)]);
    m = sym('m', [1 length(mval)]);
    p = sym('p', [1 length(pval)]);
    r = sym('r', [1 length(rval)]);
    k = sym('k', [1 length(kval)]);
    cons = sym('cons', [1 length(consv)]);
    syms sun;
    
    x = subs(x0,n,nval);
    x = subs(x,g,gval);
    x = subs(x,m,mval);
    x = subs(x,p,pval);
    x = subs(x,r,rval);
    x = subs(x,k,kval);
    x = subs(x,cons,consv);
    x = subs(x,sun,theta);
    
    if theta ~= 0
        q = sym('q', [1 length(qval)]);
        x = subs(x,q,qval);
    end
    
end
