% Simulation on Circadian Network: find amplitude and frequency

% Locke 2005b

global critical index kb mu1 morig X0 ce odeopts1...
    nval gval mval pval rval kval qval consv theta;

T3 = 3e3;
mval = morig;

amplitude = zeros(1,length(mu1));
frequency = amplitude;

%% Measure amplitude and frequency

for j = 1:length(mu1)
    
    mval(kb) = critical - critical * mu1(j);
    ce = FixedPt();
    ce = real(ce);

    if mu1(j) < 0.3
        [~,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 10*T2], X0, odeopts1);
    else
        [~,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T2], X0, odeopts1);
    end
    X0 = X(end,:);

    [t,X] = ode15s(@(t,X)Circadian_Locke2005b(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T3], X0, odeopts1);
    X0 = X(end,:);

    [PKS,LOCS]= findpeaks(X(:,index));
    periods = diff(t(LOCS));
    avgperiod = mean(periods);
    omega = 2*pi/avgperiod;
    
    xmax = mean(findpeaks(X(:,index)));
    xmin = - mean(findpeaks(-X(:,index)));
    R = 0.5 * (xmax - xmin);
    
    amplitude(j) = R / (2 * R_s);
    frequency(j) = (omega - omega_0) / omega_s;
    disp(j)
    disp(amplitude(j))
    disp(frequency(j))
    
    if j > 1
        errAmp = abs(amplitude(j)-sqrt(mu1(j))) / sqrt(mu1(j));
        errFreq = abs(frequency(j)-mu1(j)) / mu1(j);
        disp(errAmp)
        disp(errFreq)
        if errAmp > controlErr
            disp('amp')
            break
        end
        if errFreq > controlErr
            disp('freq')
            break
        end
        if isnan(errAmp)
            break
        end
    end
    
end

amplitude(j:end) = [];
frequency(j:end) = [];
