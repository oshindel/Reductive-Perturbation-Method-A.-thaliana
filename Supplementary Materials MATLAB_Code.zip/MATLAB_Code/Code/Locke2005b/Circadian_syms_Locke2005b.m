% Differential Equations of Circadian Cycle: Symbolic

% Locke 2005b Model Two

% A = c_L^m; B = c_L^c; C = c_L^n;
% D = c_T^m; E = c_T^c; F = c_T^n;
% G = c_X^m; H = c_X^c; I = c_X^n;
% J = c_Y^m; K = c_Y^c; L = c_Y^n;
% M = c_P^n;

function [dxdt,x] = Circadian_syms_Locke2005b()

    global xsize;
    
    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 5]);
    g = sym('g', [1 6]);
    m = sym('m', [1 15]);
    p = sym('p', [1 5]);
    r = sym('r', [1 8]);
    k = sym('k', [1 13]);
    q = sym('q', [1 3]);
    cons = sym('cons', [1 6]); % a b c d e f.
    syms sun;
    
    dxdt(1) = q(1) * x(13) * sun + (n(1) * x(9)^cons(1)) / (g(1)^cons(1) + x(9)^cons(1))...
        - (m(1) * x(1)) / (k(1) + x(1));
    dxdt(2) = p(1) * x(1) - r(1) * x(2) + r(2) * x(3) - (m(2) * x(2)) / (k(2) + x(2));
    dxdt(3) = r(1) * x(2) - r(2) * x(3) - (m(3) * x(3)) / (k(3) + x(3));
    dxdt(4) = (n(2) * x(12)^cons(2) / (g(2)^cons(2)...
        + x(12)^cons(2))) * (g(3)^cons(3)) / (g(3)^cons(3) + x(3)^cons(3))...
        - (m(4) * x(4)) / (k(4) + x(4));
    dxdt(5) = p(2) * x(4) - r(3) * x(5) + r(4) * x(6) - ((1 - sun) * m(5) + m(6)) * (x(5)) / (k(5) + x(5));
    dxdt(6) = r(3) * x(5) - r(4) * x(6) - ((1 - sun) * m(7) + m(8)) * (x(6)) / (k(6) + x(6));
    dxdt(7) = (n(3) * x(6)^cons(4)) / (g(4)^cons(4) + x(6)^cons(4)) - (m(9) * x(7)) / (k(7) + x(7));
    dxdt(8) = p(3) * x(7) - r(5) * x(8) + r(6) * x(9) - (m(10) * x(8)) / (k(8) + x(8));
    dxdt(9) = r(5) * x(8) - r(6) * x(9) - (m(11) * x(9)) / (k(9) + x(9));
    dxdt(10) = (sun * q(2) * x(13) + (sun * n(4) + n(5)) * g(5)^cons(5) / (g(5)^cons(5) + x(6)^cons(5)))...
         * (g(6)^cons(6) / (g(6)^cons(6) + x(3)^cons(6))) - (m(12) * x(10)) / (k(10) + x(10));
    dxdt(11) = p(4) * x(10) - r(7) * x(11) + r(8) * x(12) - m(13) * x(11) / (k(11) + x(11));
    dxdt(12) = r(7) * x(11) - r(8) * x(12) - m(14) * x(12) / (k(12) + x(12));
    dxdt(13) = (1 - sun) * p(5) - (m(15) * x(13)) / (k(13) + x(13)) - q(3) * sun * x(13);

end
