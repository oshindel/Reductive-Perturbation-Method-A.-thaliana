% Simulation on Circadian Network: find amplitude and frequency

% Fogelmark 2014

global critical index kb mu1 morig X0 ce odeopts1...
    nval mval pval rval fval qval aval tval theta;

T3 = 3e3;
mval = morig;

amplitude = zeros(1,length(mu1));
frequency = amplitude;

%% Measure amplitude and frequency

for j = 1:length(mu1)
    
    mval(kb) = critical - critical * mu1(j);
    ce = FixedPt();
    ce = real(ce);

    if mu1(j) < 0.3
        [~,X] = ode15s(@(t,X)Circadian_Fogelmark2014(t, X, nval, mval, pval,...
        rval, fval, qval, aval, tval, theta), [0 10*T2], X0+rand(size(X0)), odeopts1);
    else
        [~,X] = ode15s(@(t,X)Circadian_Fogelmark2014(t, X, nval, mval,...
        pval, rval, fval, qval, aval, tval, theta), [0 10*T2], X0, odeopts1);
    end
    X0 = X(end,:);
    
    [t,X] = ode15s(@(t,X)Circadian_Fogelmark2014(t, X, nval, mval,...
        pval, rval, fval, qval, aval, tval, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    
    X = real(X);
    [PKS,LOCS]= findpeaks(X(:,index));
    periods = diff(t(LOCS));
    avgperiod = mean(periods);
    omega = 2*pi/avgperiod;
    
    xmax = mean(findpeaks(X(:,index)));
    xmin = - mean(findpeaks(-X(:,index)));
    R = 0.5 * (xmax - xmin);
    
    amplitude(j) = R / (2 * R_s);
    frequency(j) = (omega - omega_0) / omega_s;
    disp(j)
    disp(amplitude(j))
    disp(frequency(j))
    
    if j > 1
        errAmp = abs(amplitude(j)-sqrt(mu1(j))) / sqrt(mu1(j));
        errFreq = abs(frequency(j)-mu1(j)) / mu1(j);
        disp(errAmp)
        disp(errFreq)
        if errAmp > controlErr
            disp('amp')
            break
        end
        if errFreq > controlErr
            disp('freq')
            break
        end
        if isnan(errAmp)
            break
        end
    end
    
end

amplitude(j:end) = [];
frequency(j:end) = [];
