% Generate the eigenvalue spectra of all degradation rates rangin 0 to
% biological value in paper.

global foptions odeopts1...
    xsize nval mval pval rval fval qval aval tval...
    system var morig ce X0 L;

% ind = 9; % the assumed bifurcation parameter in m
theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

%% Fogelmark2014
xsize = 35; % system size.

nval = [0, 0, 0, 0, 0.23, 20, 0, 0, 0, 0,...
    0, 0, 0, 0.1];
mval = [0.6127, 0, 0.6154, 0.4322, 1.8694, 0.4510, 1.2767, 0.1000, 0.1886, 0.0100...
    0.7611, 2.5698, 0.6654, 0.5015, 0.1791, 0.5383, 0.0750, 4.5049, 0.2, 1.8...
    0.1, 0.3007, 0.0854, 1.4996, 0.6526, 1.0319, 0.1, 0.0382, 0.0100, 4.9487...
    0.3, 9.9978, 13, 0.1561, 0.9413, 0.5060, 0.0100, 1.7736, 0.2001, 0,...
    0, 0.9229, 1.1393, 0.6769, 0.8039, 5.2729, 0.2466]; 
pval = [0, 0, 0, 0, 0, 0.6, 0.3, 0, 0, 0.2,...
    1.9117, 8, 0.7, 0.3, 3, 0.1211, 0, 0, 0, 0,...
    0, 0, 1.0113, 0, 1.0031, 0, 0, 1.0614, 10.1808];
rval = [5.6729, 1.3950, 8.5563, 3.4224, 0.1532, 25.7681, 12.2739, 1.7534, 30.7480, 9.9813...
    1.9415, 4.9865, 44.9948, 3.9036, 5.3443, 9.7396, 2.2500, 41.9449, 15.9338, 0.1090...
    3.3365, 56.5033, 3.2800, 4.3146, 41.1911, 4.7739, 1.3395, 5.9097, 0.2745, 1.4112...
    0.0398, 6.9674, 0.7146, 2.8742, 0.0604, 0.0892, 9.9585, 3.8869, 0.2669, 1.4224,...
    1.8557];
fval = [0.0602, 0.0273, 0.2654, 0.2687, 0.2899, 0.0898]; 
qval = [0.2607, 0, 0.4659];
aval = [0.3849, 92.0031, 5.3137, 7.1745, 1.9604, 8.8741, 1.5278, 3.0135];
tval = [0, 0, 0, 0, 0.2518, 0.1120, 3.7722, 28.3388, 2.5427];

morig = mval;

for j = 1:length(morig)
    
    if morig(j) == 0
        continue
    end
    
    ind = j;
    disp(j)
%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Fogelmark2014();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Fogelmark2014(t, X, nval, mval, pval,...
        rval, fval, qval, aval, tval, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
X0 = real(X0);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%%

mu = 0.01:0.01:1;
eigenvalue = zeros(xsize,length(mu));
for i = 1:length(mu)
    mval(ind) = morig(ind) * mu(i);
    L_0 = Evaluation(L);
    ce = FixedPt();
    L_0 = double(Evaluation_fp(L_0));
    [revec,evalue,levec] = eigen(L_0);
    eigenvalue(:,i) = evalue;
end

figure
title("m"+ j)
hold on
for i = 1:xsize
    scatter(real(eigenvalue(i,:)),imag(eigenvalue(i,:)));
end
plottools

end