% Substitute in values for symbolic expressions: parameter values

% Fogelmark 2014

function x = Evaluation(x0)

    global theta nval pval mval rval fval qval aval tval;

    n = sym('n', [1 length(nval)]);
    p = sym('p', [1 length(pval)]);
    m = sym('m', [1 length(mval)]);
    r = sym('r', [1 length(rval)]);
    f = sym('f', [1 length(fval)]);
    a = sym('a', [1 length(aval)]);
    t = sym('t', [1 length(tval)]);
    syms sun;
    
    x = subs(x0,n,nval);
    x = subs(x,p,pval);
    x = subs(x,m,mval);
    x = subs(x,r,rval);
    x = subs(x,f,fval);
    x = subs(x,a,aval);
    x = subs(x,t,tval);
    x = subs(x,sun,theta);
    
    if theta ~= 0
        q = sym('q', [1 length(qval)]);
        x = subs(x,q,qval);
    end
    
end
