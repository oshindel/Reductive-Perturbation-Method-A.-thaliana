% Locke2005a: Generate plot like Tokuda2019 Figure 1

% clear; clc
warning('off','all')
% load('../../Data/FInalData.mat')

global foptions odeopts1...
    xsize...
    nval gval mval pval rval kval qval consv theta...
    critical system var morig index ce X0;

foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

%% Define input values

theta = 0;

% % Typical annealed solution parameter values:
nval = [7.5038, 0.6801];
gval = [1.4992, 3.0412];
mval = [10.0982, 1.9685, 3.7511, 2.3422, 7.2482, 1.8981, 1.2];
pval = [2.1994, 9.4440, 0.5];
rval = [0.2817, 0.7676, 0.4364, 7.3021];
kval = [3.8045, 5.3087, 4.1946, 2.5356, 1.4420, 4.8600, 1.2];
qval = [4.5703, 1];
consv = [1,2];

morig = mval;

index = 1; % [1,4] = [LHY mRNA, TOC1 mRNA];
xsize = 7; % system size.
modelNum = 1;

%% Stuart-Langau parameters

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
critical = criticalValues(modelNum);
mu_critical = critical / morig(bp);
sigma_1 = real(Lambda1);
omega_1 = imag(Lambda1);
g = G(modelNum);
gp = real(g); % g-prime.
gpp = imag(g); % g-double-prime.
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);

R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);

%% Time series: LHY mRNA & TOC1 mRNA

% ODE
T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
[t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);

[pks,lctn] = findpeaks(X(t<200,scaledby));
startingPoint = lctn(4);
tshifted = t(startingPoint:end) - t(startingPoint);
tshifted = tshifted(tshifted<101);
Xshifted = X(startingPoint:end,:);
Xshifted = Xshifted(tshifted<101,:);

% Theory
mu_normal = 1;
ttheory = (0:0.001:101);

[system,var] = Circadian_syms_Locke2005a();
System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

epsilonSquared = (mu_critical - mu_normal) * morig(bp) / critical;
Xtheory = ce' + sqrt(epsilonSquared)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory));

% LHY mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,1),'.','b','SizeData',45)
plot(ttheory,Xtheory(1,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
title('Locke2005a LL-cycle','fontsize',14)
xlabel('Time (hr)','fontsize',14)
ylabel('{\it LHY} mRNA (nM)','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools

% TOC1 mRNA
figure; hold on;
scatter(tshifted,Xshifted(:,4),'.','b','SizeData',45)
plot(ttheory,Xtheory(4,:),'LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
box on
title('Locke2005a LL-cycle','fontsize',14)
xlabel('Time (hr)','fontsize',14)
ylabel('{\it TOC1} mRNA (nM)','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools

%% Bifurcation Diagrams

% Simulation points

mu1 = 0.8:0.05:ceil(mu_critical);
xmaxs1 = zeros(size(mu1));
xmins1 = xmaxs1;
ces1 = xmaxs1;
freqs1 = xmaxs1;

for i = 1:length(mu1)
    
    mval(bp) = mu1(i) * morig(bp);
    if mu1(i) <= mu_critical+0.1 && mu1(i) >= mu_critical-0.1
        T2 = 1e5;
    else
        T2 = 1e4;
    end
    
    [~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    
    [t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);
    
    [maximums,where] = findpeaks(X(:,index));
    xmaxs1(i) = mean(maximums);
    xmins1(i) = - mean(findpeaks(-X(:,index)));
    
    freqs1(i) = 1 / mean(diff(t(where)));
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);
    ces1(i) = ce(index);
    
end

% Theory curve: bifurcation diagram
mutheory = mu1(1):0.001:mu_critical;
amph = zeros(size(mutheory));
ampl = amph;

for i = 1:length(mutheory)
    
    mval(bp) = mutheory(i) * morig(bp);
    
    System = Evaluation(system);
    systemFunc = matlabFunction(System,'Vars',{var});
    [ce,~] = fsolve(systemFunc,X0,foptions);

    epsilonSquared = (mu_critical - mutheory(i)) * morig(bp) / critical;
    XRPM = ce' + sqrt(epsilonSquared)...
        .* (Ur .* R_s .* exp(1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory)...
        + Ubr .* R_s .* exp(-1i * (omega_0 + (epsilonSquared) * omega_s) * ttheory));
    amph(i) = max(XRPM(index,:));
    ampl(i) = min(XRPM(index,:));
    
end

epsilonSquared = (mu_critical - mutheory) * morig(bp) / critical;
freqtheory = (omega_0 + (epsilonSquared) * omega_s) / (2*pi);

mus_stable = [mu1(mu1<=mu_critical) mu1(mu1<=mu_critical) mu1(mu1>=mu_critical)];
mus_unstable = mu1(mu1<mu_critical);
measurements_stable = [xmaxs1(mu1<=mu_critical) xmins1(mu1<=mu_critical) ces1(mu1>=mu_critical)];
measurements_unstable = ces1(mu1<mu_critical);
mutheories = [mutheory flip(mutheory)];
theory = [ampl flip(amph)];
figure;hold on;
scatter(mus_stable, measurements_stable,'o','b','filled')
scatter(mus_unstable, measurements_unstable,'o','b')
plot(mutheories, theory,'LineWidth',2,'Color',[0.8500 0.3250 0.0980])
box on
title('Locke2005a Amplitude near Criticality','fontsize',14)
xlabel('Normalized Degradation Rate','fontsize',14)
ylabel('{\it LHY} mRNA','fontsize',14)
legend({'Stable','Unstable', 'RPM'},'fontsize',14)
plottools

figure;hold on
scatter(mu1(mu1<=mu_critical),freqs1(mu1<=mu_critical),'x','b','SizeData',45,'LineWidth',1.5)
plot(mutheory,freqtheory,'LineWidth',2,'Color',[0.8500 0.3250 0.0980])
box on
title('Locke2005a Frequency near Criticality','fontsize',14)
xlabel('Normalized Degradation Rate','fontsize',14)
ylabel('Frequency (hr^{-1})','fontsize',14)
legend({'ODE','RPM'},'fontsize',14)
plottools
