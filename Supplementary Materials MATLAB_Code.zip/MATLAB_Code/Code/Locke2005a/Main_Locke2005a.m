% Main file for simulation: Locke 2005a

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    nval gval mval pval rval kval qval consv mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 7; % system size.

% Optimal parameter values:
% nval = [16.9711, 1.3043];
% gval = [3.0351, 0.386];
% mval = [9.3383, 16.9058, 1.0214, 1.6859, 0.4212, 0.0484, 1.2];
% pval = [4.9753, 1.2947, 0.5];
% rval = [1.4563, 0.8421, 0.0451, 0.0018];
% kval = [1.3294, 0.8085, 0.1445, 0.2089, 0.3187, 0.3505, 1.2];
% qval = [2.9741, 1];
% consv = [1,2];

% % Typical annealed solution parameter values:
nval = [7.5038, 0.6801];
gval = [1.4992, 3.0412];
mval = [10.0982, 1.9685, 3.7511, 2.3422, 7.2482, 1.8981, 1.2];
pval = [2.1994, 9.4440, 0.5];
rval = [0.2817, 0.7676, 0.4364, 7.3021];
kval = [3.8045, 5.3087, 4.1946, 2.5356, 1.4420, 4.8600, 1.2];
qval = [4.5703, 1];
consv = [1,2];

morig = mval;
disp('Locke 2005a')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Locke2005a();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval,...
        pval, rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
            rval, kval, qval, consv, theta), [0 10*T2], X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);
    
    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Locke2005a
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end

end
disp('Bifurcation parameter:'); disp(bifpara)
