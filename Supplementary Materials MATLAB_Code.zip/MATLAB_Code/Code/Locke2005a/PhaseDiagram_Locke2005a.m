% Locke 2005a: Produce Phase Diagrams
% (check phase relationships

% clear; clc
% load('../../Data/FInalData.mat')
warning('off','all')

global foptions odeopts1...
    xsize...
    nval gval mval pval rval kval qval consv theta...
    critical system var morig index ce X0;

theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

% % Typical annealed solution parameter values:
nval = [7.5038, 0.6801];
gval = [1.4992, 3.0412];
mval = [10.0982, 1.9685, 3.7511, 2.3422, 7.2482, 1.8981, 1.2];
pval = [2.1994, 9.4440, 0.5];
rval = [0.2817, 0.7676, 0.4364, 7.3021];
kval = [3.8045, 5.3087, 4.1946, 2.5356, 1.4420, 4.8600, 1.2];
qval = [4.5703, 1];
consv = [1,2];

morig = mval;

index = [1,2,4,5]; % = [LHY mRNA, LHY protein(c), TOC1 mRNA,TOC1 protein(c)];
xsize = 7; % system size.
modelNum = 1;
[system,var] = Circadian_syms_Locke2005a();

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);
g = G(modelNum);
gp = real(g);
gpp = imag(g);
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);
critical = criticalValues(modelNum);

mu_normal = (critical - (morig(bp))) / critical;

%% Generate signals
% ODE

T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

[t,X] = ode15s(@(t,X)Circadian_Locke2005a(t, X, nval, gval, mval, pval,...
        rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);
begin = find(X(:,scaledby) == max(X(:,scaledby)));
t = t(begin(1):end) - t(begin(1));
X = real(X(begin(1):end,:));

% Theory

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

ttheory = (0:0.001:336);
Xtheory = ce' + sqrt(mu_normal)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal) * omega_s) * ttheory));

%% Produce Phase Diagram: LHYm vs LHYc

tpODE = 0:0.1:2*pi;
tp = 0:0.01:2*pi; % t-prime: arbitraty time

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(2)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(2)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
LHYcODE = amp2ODE * cos(tpODE + deltaPhiODE);
% relAmpODE = LHYcODE/LHYmODE;

% Theory
U = Ur(index([1 2]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
LHYcTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,LHYcODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,LHYcTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005a LHYc vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('LHY Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: TOC1m vs TOC1c

% ODE

[max1,peak1] = findpeaks(X(:,index(3)));
[max2,peak2] = findpeaks(X(:,index(4)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(3)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(4)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

TOC1mODE = amp1ODE * cos(tpODE);
TOC1cODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([3 4]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1cTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(TOC1mODE,TOC1cODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(TOC1mTheory,TOC1cTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005a TOC1c vs TOC1m')
xlabel('{\it TOC1} mRNA (nM)')
ylabel('TOC1 Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: LHYm vs TOC1m

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(3)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(3)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
TOC1mODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([1 3]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,TOC1mODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,TOC1mTheory,'LineWidth',1.5)
axis equal
box on
title('Locke2005a TOC1m vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('{\it TOC1} mRNA (nM)')
legend('ODE','RPM','fontsize',14)
plottools


