% Find sorted eigenvalues and eigenvectors
% sort with respect to real part of eigenvalues small to large

function [revec,evalue,levec] = eigen(Matrix)

    [revec,evalue,levec] = eig(Matrix,'vector');
    [evalue,order] = sort(evalue,'ComparisonMethod','real');

    if imag(evalue(end)) < 0
        temp = evalue(end);
        evalue(end) = evalue(end - 1);
        evalue(end - 1) = temp;
        
        temp_order = order(end);
        order(end) = order(end - 1);
        order(end - 1) = temp_order;
    end
    
    revec = revec(:,order);
    levec = levec(:,order);
    
end
