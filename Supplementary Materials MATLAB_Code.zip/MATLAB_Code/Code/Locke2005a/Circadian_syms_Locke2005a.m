% Differential Equations of Circadian Cycle: Symbolic

% Locke 2005a

% A = c_L^m; B = c_L^c; C = c_L^n; D = c_T^m;
% E = c_T^c; F = c_T^n; G = c_P^n;

function [dxdt,x] = Circadian_syms_Locke2005a()

    global xsize;
    
    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 2]);
    g = sym('g', [1 2]);
    m = sym('m', [1 7]);
    p = sym('p', [1 3]);
    r = sym('r', [1 4]);
    k = sym('k', [1 7]);
    q = sym('q', [1 2]);
    cons = sym('cons', [1 2]);
    syms sun;

    dxdt(1) = q(1) * x(7) * sun + (n(1) * x(6)^cons(1)) / (g(1)^cons(1) + x(6)^cons(1))...
        - (m(1) * x(1)) / (k(1) + x(1));
    dxdt(2) = p(1) * x(1) - r(1) * x(2) + r(2) * x(3) - (m(2) * x(2)) / (k(2) + x(2));
    dxdt(3) = r(1) * x(2) - r(2) * x(3) - (m(3) * x(3)) / (k(3) + x(3));
    dxdt(4) = (n(2) * g(2)^cons(2)) / (g(2)^cons(2) + x(3)^cons(2)) - (m(4) * x(4)) / (k(4) + x(4));
    dxdt(5) = p(2) * x(4) - r(3) * x(5) + r(4) * x(6) - (m(5) * x(5)) / (k(5) + x(5));
    dxdt(6) = r(3) * x(5) - r(4) * x(6) - (m(6) * x(6)) / (k(6) + x(6));
    dxdt(7) = (1 - sun) * p(3) - (m(7) * x(7)) / (k(7) + x(7)) - q(2) * sun * x(7);
    
end
