% Main file for simulation: Ohara 2015

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb theta...
    nval mval gval pval qval rval kval consv Ival mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 10; % system size.
theta0 = theta;
thetaA = theta;
thetaB = theta;
thetaC = theta;
theta = [theta0, thetaA, thetaB, thetaC];

qval = [0.2000, 1.0000, 0.4667, 0.5000];
nval = [16.9711, 1.3043];
gval = [3.0351, 0.3860];
mval = [9.3383, 16.9058, 1.0214, 1.6859, 0.4212,...
    0.0484, 0.5500, 1.0000, 1.0000];
pval = [4.9753, 1.2947, 0.4000, 0.5000, 0.5000];
rval = [1.4563, 0.8421, 0.0451, 0.0018, 1.3294];
kval = [1.3294, 0.8085, 0.1445, 0.2089, 0.3187,...
    0.3505, 1.0000, 0.2000, 0.3600];
consv = [1, 2];
Ival = [1, 1]; % Normalized intensity of I_{red} and I_{blue}.

morig = mval;
disp('Ohara 2015')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Ohara2015();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Ohara2015(t, X, nval, gval, mval,...
        pval, qval, rval, kval, consv, Ival, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_Ohara2015(t, X, nval, gval, mval,...
            pval, qval, rval, kval, consv, Ival, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Ohara2015
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end

end
disp('Bifurcation parameter:'); disp(bifpara)
