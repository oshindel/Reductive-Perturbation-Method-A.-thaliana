% Differential Equations of Circadian Cycle: Symbolic

% Ohara 2015

% 1 = c_L^m;        2 = c_L^c;          3 = c_L^n;
% 4 = c_T^m;        5 = c_T^c;          6 = c_T^n;      7 = c_p^n;
% 8 = c_{physA}^n;  9 = c_{physB}^n;    10 = c_{cry}^n.

function [dxdt,x] = Circadian_syms_Ohara2015()

    global xsize;

    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 2]);
    g = sym('g', [1 2]);
    m = sym('m', [1 9]);
    p = sym('p', [1 5]);
    q = sym('q', [1 4]);
    r = sym('r', [1 4]);
    k = sym('k', [1 9]);
    cons = sym('cons', [1 2]);
    sun = sym('sun', [1 4]);
    I = sym('I', [1 2]);
    
    % Recurring expressions:
    L_physA = q(1) * x(8) * sun(2);
    L_physB = q(3) * x(9) * log(I(1) + 1) * sun(2);
    L_cry = q(4) * x(10) * log(I(2) + 1) * sun(3);
    L = L_physA + L_physB + L_cry;
    
    % Differential equations:
    dxdt(1) = L + n(1) * x(6)^cons(1) / (g(1)^cons(1) + x(6)^cons(1))...
        - m(1) * x(1) / (k(1) + x(1));
    dxdt(2) = p(1) * x(1) - r(1) * x(2) + r(2) * x(3) - m(2) * x(2) / (k(2) + x(2));
    dxdt(3) = r(1) * x(2) - r(2) * x(3) - m(3) * x(3) / (k(3) + x(3));
    dxdt(4) = n(2) * g(2)^cons(2) / (g(2)^cons(2) + x(3)^cons(2))...
        - m(4) * x(4) / (k(4) + x(4));
    dxdt(5) = p(2) * x(4) - r(3) * x(5) + r(4) * x(6) - m(5) * x(5) / (k(5) + x(5));
    dxdt(6) = r(3) * x(5) - r(4) * x(6) - m(6) * x(6) / (k(6) + x(6));
    dxdt(7) = (1 - sun(1)) * p(3) - m(7) * x(7) / (k(7) + x(7)) - q(2) * sun(1) * x(7);
    dxdt(8) = (1 - sun(2)) * p(3) - m(7) * x(8) / (k(7) + x(8)) - q(2) * sun(2) * x(8);
    dxdt(9) = p(4) - m(8) * x(9) / (k(8) + x(9));
    dxdt(10) = p(5) - m(9) * x(10) / (k(9) + x(10));
    
end
