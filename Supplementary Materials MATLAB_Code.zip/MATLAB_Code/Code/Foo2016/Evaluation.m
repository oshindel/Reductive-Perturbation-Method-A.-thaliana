% Substitute in values for symbolic expressions: parameter values

% Foo 2016

function x = Evaluation(x0)

    global theta aval phiv;

    phi = sym('phi', [1 length(phiv)]);
    syms sun a;
    
    x = subs(x0,phi,phiv);
    x = subs(x,a,aval);
    x = subs(x,sun,theta);
    
end
