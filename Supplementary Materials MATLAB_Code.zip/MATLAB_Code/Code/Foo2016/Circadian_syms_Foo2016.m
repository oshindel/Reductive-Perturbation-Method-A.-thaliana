% Differential Equations of Circadian Cycle: Symbolic

% Foo 2016

% 1 = c_P;          2 = c_L^m;      3 = c_L^p;
% 4 = c_{P9}^m;     5 = c_{P9}^p;   6 = c_{P7}^m;   7 = c_{P7}^p;
% 8 = c_{P5}^m;     9 = c_{P5}^p;   10 = c_T^m;     11 = c_T^p;
% 12 = c_{EC}^p;    13 = c_{R8}^m;  14 = c_{R8}^p;
% 15 = c_{E3}^m;    16 = c_{E3}^p;
% 17 = c_{E4}^m;    18 = c_{E4}^p;
% 19 = c_{LUX}^m;   20 = c_{LUX}^p;
% 21 = c_{GI}^m;    22 = c_{GI}^p;
% 23 = c_{CP}^p;    24 = c_{ZTL}^p;

function [dxdt,x] = Circadian_syms_Foo2016()

    global xsize;

    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);

    phi = sym('phi', [1 77]);
    syms a;
    syms sun;
    
    dxdt(1) = - phi(1) * sun - phi(2) * x(1) + phi(3);
    dxdt(2) = phi(4) / (phi(5)^a + phi(6) * (phi(75) * x(5) + phi(76) * x(7)...
        + phi(77) * x(9))^a) - phi(7) * x(2);
    dxdt(3) = phi(8) * x(2) - phi(9) * x(3);
    dxdt(4) = phi(10) * x(1) * sun + phi(11) ...
        + phi(12) * x(3)^a / (phi(13)^a + x(3)^a) - phi(14) * x(4);
    dxdt(5) = phi(15) * x(4) - phi(16) * x(5);
    dxdt(6) = phi(17) / ((phi(18) + x(12)) * (phi(19)^a + x(11)^a)) - phi(20) * x(6);
    dxdt(7) = phi(21) * x(6) - phi(22) * x(7);
    dxdt(8) = phi(23) / ((phi(24)^a + x(11)^a) * (phi(25)^a + x(3)^a)) - phi(26) * x(8);
    dxdt(9) = phi(27) * x(8) - phi(28) * x(9);
    dxdt(10) = phi(29) / ((phi(30) + x(12)) * (phi(31)^a + x(3)^a)) - phi(32) * x(10);
    dxdt(11) = phi(33) * x(10) - phi(34) * x(11);
    dxdt(12) = phi(35) * (x(16) * x(18) * x(20)) - phi(36) * x(12);
    dxdt(13) = phi(37) / (phi(38)^a + (phi(77) * x(9))^a) - phi(39) * x(13);
    dxdt(14) = phi(40) * x(13) - phi(41) * x(14);
    dxdt(15) = phi(42) / (phi(43)^a + x(3)^a) - phi(44) * x(15);
    dxdt(16) = phi(45) * x(15) - phi(46) * x(16);
    dxdt(17) = phi(47) / ((phi(48) + x(12)) * (phi(49)^a + x(3)^a)) - phi(50) * x(17);
    dxdt(18) = phi(51) * x(17) - phi(52) * x(18);
    dxdt(19) = phi(53) / ((phi(54) + x(12)) * (phi(55)^a + x(3)^a)) - phi(56) * x(19);
    dxdt(20) = phi(57) * x(19) - phi(58) * x(20);
    dxdt(21) = phi(59) / ((phi(60)^a + x(3)^a) * (phi(61)^a + x(11)^a)...
        * (phi(62)^a + x(16)^a)) - phi(63) * x(21);
    dxdt(22) = phi(64) * x(21) - phi(65) * x(16) * x(23) * x(22) - phi(66) * x(22);
    dxdt(23) = - phi(67) * sun - phi(68) * x(23) + phi(69);
    dxdt(24) = (phi(70) * x(24) * x(22)) / (1 + phi(71) * x(24) + phi(72) * x(22)) ...
        - phi(73) * x(24) + phi(74);
    
end
