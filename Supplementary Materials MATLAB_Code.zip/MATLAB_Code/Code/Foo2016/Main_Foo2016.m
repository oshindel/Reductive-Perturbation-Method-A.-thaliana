% Main file for simulation: Foo 2016

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    aval phiv mk...
    critical system var phiorig I index ce X0;

%% Import Parameter Values

xsize = 24; % system size.

aval = 2; % Hill coefficient.
phiv = [0.43301, 0.4949, 0.4358,...                                 % plight 1-3
    1.9601, 0.7412, 0.3821, 2.7804,...                              % mLHY  4-7
    0.83604, 0.64719,...                                            % pLHY  8-9
    0.73369, 6.4976e-05, 0.75976, 1.3352, 0.59706,...               % mPRR9 10-14
    0.50077, 0.22337,...                                            % pPRR9 15-16
    0.0099479, 0.034706, 0.87726, 0.23934,...                       % mPRR7 17-20
    0.23744, 0.18571,...                                            % pPRR7 21-22
    0.026728, 0.13201, 0.031588, 40.9795,...                        % mPRR5 23-26
    4.0753, 2.5872,...                                              % pPRR5 27-28
    0.01501, 0.036926, 0.011307, 12.2192,...                        % mTOC1 29-32
    0.40049, 0.31171,...                                            % pTOC1 33-34
    0.80816, 0.37854,...                                            % pEC   35-36
    2.2417, 1.4074, 1.5159,...                                      % mRVE8 37-39
    0.32848, 0.14877,...                                            % pRVE8 40-41
    0.014607, 0.23392, 0.27265,...                                  % mELF3 42-44
    14.0123, 17.3569,...                                            % pELF3 45-46
    0.014384, 0.032117, 0.051737, 11.007,...                        % mELF4 47-50
    0.67365, 0.39718,...                                            % pELF4 51-52
    0.028907, 0.01727, 0.034063, 26.4166,...                        % mLUX  53-56
    2.461, 1.4794,...                                               % pLUX  57-58
    0.0002445, 0.072434, 0.11811, 0.456, 0.58448,...                % mGI   59-63
    0.40246, 0.78572, 0.020811,...                                  % pGI   64-66
    0.80938, 0.8102, 0.91424,...                                    % pCOP1 67-69
    2.3354, 1.275, 1.5983, 0.44539, 0.027925,...                    % pZTL  70-74
    0.52644, 1.3764, 11.6684];                                      % Homolog Scale 75-77

I = [3, 7, 9, 14, 16, 20, 22, 26, 28, 32, 34, 36, 39, 41, 44,...
    46, 50, 52, 56, 58, 63, 66, 69, 74]; % index of degradation rates
phiorig = phiv;
disp('Foo 2016')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Foo2016();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode23(@(t,X)Circadian_Foo2016(t, X, phiv, aval, theta), [0 T1],...
    ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    phiv = phiorig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = phiorig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    phiv(kb) = critical - critical * mu1(2);
    [~,X] = ode23(@(t,X)Circadian_Foo2016(t, X, phiv, aval, theta), [0 T2],...
            X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Foo2016
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end

end
disp('Bifurcation parameter:'); disp(bifpara)
