% Generate Stuart-Landau parameters from amplitude equation

function [g,omega_0] = Generate_values()

    global L M N xsize index critical phiv kb ce phiorig;
    
    %% Create and evaluate tensors
    
    third_tensor();
    fourth_tensor();

    phiv = phiorig;
    phiv(kb) = critical;
    L_0 = Evaluation(L);
    M_0 = Evaluation(M);
    N_0 = Evaluation(N);

    ce = FixedPt();
    L_0 = double(Evaluation_fp(L_0));
    M_0 = double(Evaluation_fp(M_0));
    N_0 = double(Evaluation_fp(N_0));
    
    %% Calculate g from L_0
    
    [revec,evalue,levec] = eigen(L_0);
    % Values at criticality:
    % revec = right eigenvectors; levec = left eigenvectors;
    % eval = eigenvalues.
    
    imagev = imag(evalue);
    omega_0 = imagev(find(imagev,1,'last'));
    Ur = revec(:,end); % U: right eigenvector.
    Ul = levec(:,end)'; % U-star: left eigenvector.
    Ubr = revec(:,end-1); % U-bar: complex conjugate.

    % Normalization:
    Ur = Ur/(Ur(index));
    Ubr = Ubr/(Ubr(index));
    normalization = Ul * Ur;
    Ul = Ul / normalization;

    Ap = (2 * omega_0 * eye(xsize) * 1i - L_0)^(-1) * Mult(M_0,Ur) * Ur;
    A0 = -2 * L_0^(-1) * Mult(M_0,Ur) * Ubr;

    g = -2 * Ul * (Mult(M_0,Ur) * A0 + Mult(M_0,Ubr) * Ap)...
        - 3 * Ul * (Mult(Mult(N_0,Ur),Ur) * Ubr);

end
