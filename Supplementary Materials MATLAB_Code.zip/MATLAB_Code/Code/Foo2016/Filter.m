% Filter the degradation rates that lead to bifurcation
% between 0 and optimal value
% and create array with corresponding critical values

% idegradation1 returns the indices of degradation rates that satisfy the critiria;
% critical_values1 gives the critical value of those degradation rates.

function [idegradation, critical_values] = Filter()

    global phiv phiorig I
    
    idegradation = [];
    critical_values = [];
    ideg = 1;
    
    for ii = 1:length(I)
        i = I(ii);
        disp(i)
        phiv = phiorig;
        if phiv(i) == 0
            continue
        end
        
        [lambda, ~] = Calc_lambdas();
        if real(lambda) > 0 % supercritical
            increment = 0.1;
            if phiorig(i) > 15
                bound = phiorig(i) * [1 2];
            elseif phiorig(i) < 1
                bound = phiorig(i) * [1 10];
            else
                bound = phiorig(i) * [1 5];
            end
            sgn = 1;
        elseif real(lambda) < 0 % subcritical
            increment = - 0.1;
            bound = phiorig(i) * [1/3 1];
            sgn = -1;
        end
        
        inrange = 1;
        phiv(i) = phiv(i) + increment;
        while sign(real(lambda)) == sgn && inrange
            [lambda, ~] = Calc_lambdas();
            phiv(i) = phiv(i) + increment;
            inrange = phiv(i) > bound(1) && phiv(i) < bound(2);
        end
        
        if ~(sign(real(lambda)) == sgn)
            idegradation(ideg) = i;
            range = sort([phiv(i),phiv(i) - 2*increment]);
            critical_values(ideg) = Solve_cp(range,i);
            ideg = ideg + 1;
        end
    end
    disp('Potential bifurcation parameters:');
    disp(idegradation)
    
end
