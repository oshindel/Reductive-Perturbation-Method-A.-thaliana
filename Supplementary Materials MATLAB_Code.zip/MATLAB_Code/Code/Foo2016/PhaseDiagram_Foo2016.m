% Foo 2016: Produce Phase Diagrams

clear; clc
load('../../Data/FInalData.mat')
warning('off','all')

global foptions odeopts1...
    xsize...
    aval phiv theta...
    critical system var phiorig index ce X0;

theta = 1;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

aval = 2; % Hill coefficient.
phiv = [0.43301, 0.4949, 0.4358,...                                 % plight 1-3
    1.9601, 0.7412, 0.3821, 2.7804,...                              % mLHY  4-7
    0.83604, 0.64719,...                                            % pLHY  8-9
    0.73369, 6.4976e-05, 0.75976, 1.3352, 0.59706,...               % mPRR9 10-14
    0.50077, 0.22337,...                                            % pPRR9 15-16
    0.0099479, 0.034706, 0.87726, 0.23934,...                       % mPRR7 17-20
    0.23744, 0.18571,...                                            % pPRR7 21-22
    0.026728, 0.13201, 0.031588, 40.9795,...                        % mPRR5 23-26
    4.0753, 2.5872,...                                              % pPRR5 27-28
    0.01501, 0.036926, 0.011307, 12.2192,...                        % mTOC1 29-32
    0.40049, 0.31171,...                                            % pTOC1 33-34
    0.80816, 0.37854,...                                            % pEC   35-36
    2.2417, 1.4074, 1.5159,...                                      % mRVE8 37-39
    0.32848, 0.14877,...                                            % pRVE8 40-41
    0.014607, 0.23392, 0.27265,...                                  % mELF3 42-44
    14.0123, 17.3569,...                                            % pELF3 45-46
    0.014384, 0.032117, 0.051737, 11.007,...                        % mELF4 47-50
    0.67365, 0.39718,...                                            % pELF4 51-52
    0.028907, 0.01727, 0.034063, 26.4166,...                        % mLUX  53-56
    2.461, 1.4794,...                                               % pLUX  57-58
    0.0002445, 0.072434, 0.11811, 0.456, 0.58448,...                % mGI   59-63
    0.40246, 0.78572, 0.020811,...                                  % pGI   64-66
    0.80938, 0.8102, 0.91424,...                                    % pCOP1 67-69
    2.3354, 1.275, 1.5983, 0.44539, 0.027925,...                    % pZTL  70-74
    0.52644, 1.3764, 11.6684];                                      % Homolog Scale 75-77

phiorig = phiv;

index = [2,3,10,11]; % = [LHY mRNA, LHY protein(c), TOC1 mRNA,TOC1 protein(c)];
xsize = 24; % system size.
modelNum = 9;
[system,var] = Circadian_syms_Foo2016();

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);
g = G(modelNum);
gp = real(g);
gpp = imag(g);
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);
critical = criticalValues(modelNum);

mu_normal = (critical - (phiorig(bp))) / critical;

%% Generate signals
% ODE

T1 = 1e4;
[~,X] = ode23(@(t,X)Circadian_Foo2016(t, X, phiv, aval, theta), [0 T1],...
    ones(1,xsize), odeopts1);
X0 = real(X(end,:));

[t,X] = ode23(@(t,X)Circadian_Foo2016(t, X, phiv, aval, theta), [0 T1],...
    X0, odeopts1);
X = real(X);
begin = find(X(:,scaledby) == max(X(:,scaledby)));
t = t(begin(1):end) - t(begin(1));
X = real(X(begin(1):end,:));

% Theory

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

ttheory = (0:0.001:336);
Xtheory = ce' + sqrt(mu_normal)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal) * omega_s) * ttheory));

%% Produce Phase Diagram: LHYm vs LHYc

tpODE = 0:0.1:2*pi;
tp = 0:0.01:2*pi; % t-prime: arbitraty time

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(2)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(2)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
LHYcODE = amp2ODE * cos(tpODE + deltaPhiODE);
% relAmpODE = LHYcODE/LHYmODE;

% Theory
U = Ur(index([1 2]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
LHYcTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,LHYcODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,LHYcTheory,'LineWidth',1.5)
axis equal
box on
title('Foo2016 LHYc vs LHYm')
xlabel('{\it LHY} mRNA')
ylabel('LHY Protein')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: TOC1m vs TOC1c

% ODE

[max1,peak1] = findpeaks(X(:,index(3)));
[max2,peak2] = findpeaks(X(:,index(4)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(3)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(4)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

TOC1mODE = amp1ODE * cos(tpODE);
TOC1cODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([3 4]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end
deltaPhiTheory = deltaPhiTheory - pi;

TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1cTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(TOC1mODE,TOC1cODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(TOC1mTheory,TOC1cTheory,'LineWidth',1.5)
axis equal
box on
title('Foo2016 TOC1c vs TOC1m')
xlabel('{\it TOC1} mRNA')
ylabel('TOC1 Protein')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: LHYm vs TOC1m

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(3)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:100)) - t(peak1(1:100))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(3)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
TOC1mODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([1 3]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end
deltaPhiTheory = deltaPhiTheory + pi;

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,TOC1mODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,TOC1mTheory,'LineWidth',1.5)
axis equal
box on
title('Foo2016 TOC1m vs LHYm')
xlabel('{\it LHY} mRNA')
ylabel('{\it TOC1} mRNA')
legend('ODE','RPM','fontsize',14)
plottools


