% Solve for critical value of bifurcation parameter

function [cp] = Solve_cp(range, ind)

    global L mval ce;
    
    mini = range(1);
    maxi = range(2);
    
    for i = 1:30
        bp = (maxi + mini) / 2;
        mval(ind) = bp;

        ce = FixedPt();
        jacobian = Evaluation(L);
        jacobian = double(Evaluation_fp(jacobian));
        
        [~,ev,~] = eigen(jacobian);
        if real(ev(end)) < 0
            maxi = bp;
        else
            mini = bp;
        end
        
        if maxi - mini < 1e-4
            break
        end
    end

    cp = (maxi + mini) / 2;

end
