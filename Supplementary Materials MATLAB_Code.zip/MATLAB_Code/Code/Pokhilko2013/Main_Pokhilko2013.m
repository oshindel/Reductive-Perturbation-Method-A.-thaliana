% Main file for simulation: Pokhilko 2013

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    nval gval mval pval qval consv mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 32; % system size.

qval = [1, 1.56, 3];
nval = [2.6, 0.35, 0.29, 0.04, 0.4, 20, 0.1, 0.5, 0.6, 0.3,...
    0.6, 9, 2, 0.1, 2, 0, 0.5, 0.5, 0.2];
gval = [0.1, 0.01, 0.6, 0.006, 0.2, 0.3, 1, 0.04, 0.3, 0.5,...
    0.7, 0.1, 1, 0.02, 0.4, 0.3, 0.6, 0.4, 0.4, 0.03,...
    0.4, 0.1, 0.6, 0.3, 0.5, 0.3, 0.2, 0.1, 1];
mval = [0.54, 0.24, 0.2, 0.2, 0.3, 0.2, 0.1, 0.5, 0.2, 0.1,...
    1, 1, 0.32, 0.4, 0.7, 0.5, 0.5, 3.4, 0.9, 0.6,...
    0.08, 0.1, 0.5, 0.5, 0.9, 0.5, 0.1, 28, 0.3, 1,...
    0.1, 0.2, 13, 0.6, 0.3, 0.3, 0.4, 0.3, 0.2];
pval = [0.13, 0.27, 0.1, 0.5, 1, 0.2, 0.3, 0.6, 0.8, 0.54,...
    0.5, 10, 0.1, 0.14, 2, 0.62, 17, 4, 1 ,0.1,...
    1, 0.5 ,0.37, 11, 2, 0.3, 0.8, 2, 0.1, 0.9,...
    0.1, 0.1, 0.2];
consv = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1]; % last entry is A_0

morig = mval;
disp('Pokhilko 2013')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Pokhilko2013();
Jacobian();

% Set initiazl values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Pokhilko2013(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X(end,:),foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_Pokhilko2013(t, X, nval, gval, mval,...
            pval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Pokhilko2013
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end

end

disp('Bifurcation parameter:'); disp(bifpara)
