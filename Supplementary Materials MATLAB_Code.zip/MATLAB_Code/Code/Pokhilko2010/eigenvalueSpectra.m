% Generate the eigenvalue spectra of all degradation rates rangin 0 to
% biological value in paper.

global foptions odeopts1...
    xsize nval gval mval pval qval consv...
    system var morig ce X0 L;

% ind = 9; % the assumed bifurcation parameter in m
theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

%% Pokhilko2010
xsize = 19; % system size.

qval = [0.8, 0.5, 2.9, 0.6];
nval = [1.8, 0.76, 0.065, 0, 3.95, 1.45, 0.2, 0.42, 0.26, 0.18,...
    0.71, 2.3, 0.4];
gval = [0.1, 0.28, 0.4, 1.07, 0.3, 0.3, 0.18, 0.14, 0.3, 0.7,...
    0.7, 0.5, 0.6, 0.17, 0.4, 0.2];
mval = [0.54, 0.24, 0.2, 0.2, 0.3, 0.25, 0.5, 0.1, 1, 0.3,...
    1, 1, 0.32, 0.28, 0.31, 0.5, 0.3, 1, 0.2, 1.2,...
    0.2, 2, 1, 0.405, 0.28, 0.14];
pval = [0.4, 0.27, 0.1, 0.246, 1, 0.44, 0.3, 0.7, 0.4, 0.36,...
    0.23, 30, 0.4, 0.45, 0.05];
consv = [2, 3, 3, 2.5, 2, 3, 2, 2, 3, 3,...
    3, 2, 2, 1, 2, 3];

morig = mval;

for j = 1:length(morig)
    
    ind = j;
%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Pokhilko2010();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Pokhilko2010(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);
X0 = real(X0);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%%

mu = 0.01:0.01:1;
eigenvalue = zeros(xsize,length(mu));
for i = 1:length(mu)
    mval(ind) = morig(ind) * mu(i);
    L_0 = Evaluation(L);
    ce = FixedPt();
    L_0 = double(Evaluation_fp(L_0));
    [revec,evalue,levec] = eigen(L_0);
    eigenvalue(:,i) = evalue;
end

figure
title("m"+ j)
hold on
for i = 1:xsize
    scatter(real(eigenvalue(i,:)),imag(eigenvalue(i,:)));
end

end