% Main file for simulation: Pokhilko 2010

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    nval gval mval pval qval consv mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 19; % system size.

qval = [0.8, 0.5, 2.9, 0.6];
nval = [1.8, 0.76, 0.065, 0, 3.95, 1.45, 0.2, 0.42, 0.26, 0.18,...
    0.71, 2.3, 0.4]; % the last entry is n_0.
gval = [0.1, 0.28, 0.4, 1.07, 0.3, 0.3, 0.18, 0.14, 0.3, 0.7,...
    0.7, 0.5, 0.6, 0.17, 0.4, 0.2];
mval = [0.54, 0.24, 0.2, 0.2, 0.3, 0.25, 0.5, 0.1, 1, 0.3,...
    1, 1, 0.32, 0.28, 0.31, 0.5, 0.3, 1, 0.2, 1.2,...
    0.2, 2, 1, 0.405, 0.28, 0.14];
pval = [0.4, 0.27, 0.1, 0.246, 1, 0.44, 0.3, 0.7, 0.4, 0.36,...
    0.23, 30, 0.4, 0.45, 0.05];
consv = [2, 3, 3, 2.5, 2, 3, 2, 2, 3, 3,...
    3, 2, 2, 1, 2, 3];

morig = mval;
disp('Pokhilko 2010')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Pokhilko2010();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Pokhilko2010(t, X, nval, gval, mval,...
        pval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_Pokhilko2010(t, X, nval, gval, mval,...
            pval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    [t,X] = ode15s(@(t,X)Circadian_Pokhilko2010(t, X, nval, gval, mval,...
            pval, qval, consv, theta), [0 T2], X0, odeopts1);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Pokhilko2010
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end
    
end
disp('Bifurcation parameter:'); disp(bifpara)
