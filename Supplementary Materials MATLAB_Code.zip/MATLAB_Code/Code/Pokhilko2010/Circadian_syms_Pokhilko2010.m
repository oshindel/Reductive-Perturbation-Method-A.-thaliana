% Differential Equations of Circadian Cycle: Symbolic

% Pokhilko 2010

% 1 = c_L^m; 2 = c_L; 3 = c_{L mod};
% 4 = c_T^m; 5 = c_T; 6 = c_{T mod};
% 7 = c_Y^m; 8 = c_Y;
% 9 = c_P;
% 10 = c_{P9}^m; 11 = c_{P9};
% 12 = c_{P7}^m; 13 = c_{P7};
% 14 = c_{NI}^m; 15 = c_{NI};
% 16 = c_{G}^m; 17 = c_{G};
% 18 = c_{ZTL}; 19 = c_{ZG};

function [dxdt,x] = Circadian_syms_Pokhilko2010()

    global xsize;
    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 13]); % n(13) is n(0).
    g = sym('g', [1 16]);
    m = sym('m', [1 26]);
    p = sym('p', [1 15]);
    q = sym('q', [1 4]);
    cons = sym('cons', [1 16]);
    syms sun;    
    
    dxdt(1) = (g(1)^cons(1) / (g(1)^cons(1) + (x(11) + x(13) + x(15))^cons(1)))...
        * (sun * q(1) * x(9) + n(13) * sun + n(1) * x(6)^cons(2) / (x(6)^cons(2) + g(2)^cons(2)))...
        - (m(1) * sun + m(2) * (1 - sun)) * x(1);
    dxdt(2) = (p(1) * sun + p(2) * (1 - sun)) * x(1) - m(3) * x(2)...
        - p(3) * x(2)^cons(3) / (x(2)^cons(3) + g(3)^cons(3));
    dxdt(3) = p(3) * x(2)^cons(3) / (x(2)^cons(3) + g(3)^cons(3)) - m(4) * x(3);
    dxdt(4) = (x(2) * (x(8)^cons(4) / (x(8)^cons(4) + g(4)^cons(4))) + n(3))...
        * (g(5)^cons(5) / (g(5)^cons(5) + x(2)^cons(5))) - m(5) * x(4);
    dxdt(5) = p(4) * x(4) - (m(6) * sun + m(7) * (1 - sun)) * x(5) * (x(18) * p(5) + x(19)) - m(8) * x(5);
    dxdt(6) = p(15) * x(5)^cons(6) / (x(5)^cons(6) + g(6)^cons(6))...
        - (m(25) * sun + m(26) * (1 - sun)) * x(6);
    dxdt(7) = sun * q(2) * x(9) + (n(5) * sun + n(6) * (1 - sun))...
        * (g(7)^cons(16) / (g(7)^cons(16) + x(5)^cons(16)))...
        * (g(16)^cons(7) / (g(16)^cons(7) + x(2)^cons(7))) - m(9) * x(7);
    dxdt(8) = p(6) * x(7) - m(10) * x(8);
    dxdt(9) = p(7) * (1 - sun) * (1 - x(9)) - m(11) * x(9) * sun;
    dxdt(10) = sun * q(3) * x(9) + n(7) * (g(8)^cons(8) / (g(8)^cons(8) + x(5)^cons(8)))...
         * (x(2)^cons(9) / (g(9)^cons(9) + x(2)^cons(9))) - m(12) * x(10);
    dxdt(11) = p(8) * x(10) - (m(13) * sun + m(22) * (1 - sun)) * x(11);
    dxdt(12) = n(8) * (x(2) + x(3))^cons(10) / (g(10)^cons(10) + (x(2) + x(3))^cons(10))...
         + n(9) * x(11)^cons(11) / (g(11)^cons(11) + x(11)^cons(11)) - m(14) * x(12);
    dxdt(13) = p(9) * x(12) - (m(15) * sun + m(23) *(1 - sun)) * x(13);
    dxdt(14) = n(10) * x(3)^cons(12) / (g(12)^cons(12) + x(3)^cons(12))...
         + n(11) * x(13)^cons(13) / (g(13)^cons(13) + x(13)^cons(13)) - m(16) * x(14);
    dxdt(15) = p(10) * x(14) - (m(17) * sun + m(24) * (1 - sun)) * x(15);
    dxdt(16) = sun * q(4) * x(9) + (g(14)^cons(14) / (g(14)^ cons(14) + x(5)^cons(14)))...
         * (g(15)^cons(15) / (x(2)^cons(15) + g(15)^cons(15))) * n(12) * sun - m(18) * x(16);
    dxdt(17) = p(11) * x(16) - p(12) * sun * x(18) * x(17) + p(13) * x(19) * (1 - sun)...
         - m(19) * x(17);
    dxdt(18) = p(14) - p(12) * sun * x(18) * x(17) + p(13) * x(19) * (1 - sun) - m(20) * x(18);
    dxdt(19) = p(12) * sun * x(18) * x(17) - p(13) * x(19) * (1 - sun) - m(21) * x(19);
    
end
