% Substitute in values for symbolic expressions: parameter values

% DeCaluwe 2016

function x = Evaluation(x0)

    global theta vval kval pval dval Kval;

    v = sym('v', [1 length(vval)]);
    k = sym('k', [1 length(kval)]);
    p = sym('p', [1 length(pval)]);
    d = sym('d', [1 length(dval)]);
    K = sym('K', [1 length(Kval)]);
    syms sun;
    
    x = subs(x0,v,vval);
    x = subs(x,k,kval);
    x = subs(x,p,pval);
    x = subs(x,d,dval);
    x = subs(x,K,Kval);
    x = subs(x,sun,theta);
    
end
