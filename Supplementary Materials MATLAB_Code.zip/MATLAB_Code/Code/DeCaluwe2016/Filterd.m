% Filter the degradation rates that lead to bifurcation
% between 0 and optimal value
% and create array with corresponding critical values

% idegradation1 returns the indices of degradation rates that satisfy the critiria;
% critical_values1 gives the critical value of those degradation rates.

function [idegradation, critical_values] = Filterd()

    global dval dorig
    
    idegradation = [];
    critical_values = [];
    ideg = 1;
    
    for i = 1:length(dval)
        disp(i)
        dval = dorig;
        if dval(i) == 0
            continue
        end
        
        [lambda, ~] = Calc_lambdas();
        if real(lambda) > 0 % supercritical
            increment = 0.1;
            if dorig(i) > 15
                bound = dorig(i) * [1 2];
            elseif dorig(i) < 1
                bound = dorig(i) * [1 10];
            else
                bound = dorig(i) * [1 5];
            end
            sgn = 1;
        elseif real(lambda) < 0 % subcritical
            increment = - 0.1;
            bound = dorig(i) * [1/3 1];
            sgn = -1;
        end
        
        inrange = 1;
        dval(i) = dval(i) + increment;
        while sign(real(lambda)) == sgn && inrange
            [lambda, ~] = Calc_lambdas();
            dval(i) = dval(i) + increment;
            inrange = dval(i) > bound(1) && dval(i) < bound(2);
        end
        
        if ~(sign(real(lambda)) == sgn)
            idegradation(ideg) = i;
            range = sort([dval(i),dval(i) - 2*increment]);
            critical_values(ideg) = Solve_cp_d(range,i);
            ideg = ideg + 1;
        end
    end
    disp('Potential bifurcation parameters in d:');
    disp(idegradation)
    
end
