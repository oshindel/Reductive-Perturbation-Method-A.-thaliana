% Calculate sigma_1 and omega_1 for all potential bifurcation paramters

function [sigma1s, omega1s] = Calc_sigma_omega_d(idegradation, criticals)
    
    global dval dorig
    
    mu1 = -0.1:0.005:0.1;
    sigma1s = zeros(size(idegradation));
    omega1s = zeros(size(idegradation));
    
    for i = 1:length(idegradation)
        dval = dorig;
        j = idegradation(i); % re-define the index to be the index of degradation rate.
        lambdas = zeros(size(mu1));
        
        for k = 1:length(mu1)
            dval(j) = criticals(i) - mu1(k);
            [lambda,~] = Calc_lambdas();
            lambdas(k) = lambda;
        end
        
        n = 2; % highest degree of polyfit.
        P = polyfit(mu1,real(lambdas),n);
        Q = polyfit(mu1,imag(lambdas),n);
        sigma1s(i) = P(n);
        omega1s(i) = Q(n);
    end
        
end