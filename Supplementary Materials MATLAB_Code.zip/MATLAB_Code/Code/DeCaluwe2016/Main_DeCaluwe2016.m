% Main file for simulation: DeCaluwe 2016

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    ScaledBy REV LEV...
    theta foptions odeopts1 controlErr

global foptions odeopts1...
    xsize kb...
    vval kval pval dval Kval mk...
    critical system var korig dorig index ce X0;

%% Import Parameter Values

xsize = 9; % system size.

vval = [4.6, 3.0, 1.3, 1.5, 5.0, 1.0, 1.5]; % Synthesis: [v1 v1L v2A v2B v2L v3 v4].
kval = [0.53, 0.21, 0.35, 0.56, 0.57]; % Degradation: [k1L k1D k2 k3 k4].
pval = [0.76, 0.42, 1.0, 0.64, 1.0]; % Translation: [p1 p1L p2 p3 p4].
dval = [0.68, 0.50, 0.30, 0.48, 0.78, 1.2, 0.38]; % Degradation: [d1 d2D d2L d3D d3L d4D d4L].
Kval = [0.16, 1.2, 0.24, 0.23, 0.30, 0.46, 2.0, 0.36, 1.9, 1.9]; % Activation-Inhibition.

korig = kval;
dorig = dval;
disp('DeCaluwe 2016')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_DeCaluwe2016();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_DeCaluwe2016(t, X, vval, kval, pval, dval,...
        Kval, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[idegk, critk] = Filterk();
kval = korig;
[idegd, critd] = Filterd();
dval = dorig;
[sigma1sk, omega1sk] = Calc_sigma_omega_k(idegk, critk);
kval = korig;
[sigma1sd, omega1sd] = Calc_sigma_omega_d(idegd, critd);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
dval = dorig;
for i = 1:length(idegk)
    
    kval = korig;
    kb = idegk(i);
    disp(kb)
    critical = critk(i);
    sigma_1 = sigma1sk(i);
    omega_1 = omega1sk(i);
    mk = korig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    kval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_DeCaluwe2016(t, X, vval, kval, pval, dval,...
            Kval, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    [t,X] = ode15s(@(t,X)Circadian_DeCaluwe2016(t, X, vval, kval, pval, dval,...
            Kval, theta), [0 T2], X0, odeopts1);
        
    X = real(X);
    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values_k();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_DeCaluwe2016_k
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        bifarray = 'k';
        criticalval = critical;
    end
    
end

kval = korig;
for i = 1:length(idegd)
    
    dval = dorig;
    kb = idegd(i);
    critical = critd(i);
    sigma_1 = sigma1sd(i);
    omega_1 = omega1sd(i);
    mk = dorig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    dval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_DeCaluwe2016(t, X, vval, kval, pval, dval,...
            Kval, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);
    [t,X] = ode15s(@(t,X)Circadian_DeCaluwe2016(t, X, vval, kval, pval, dval,...
            Kval, theta), [0 T2], X0, odeopts1);
        
    X = real(X);
    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values_d();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_DeCaluwe2016_d
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        bifarray = 'd';
        criticalval = critical;
    end

end
disp('Bifurcation parameter:'); disp(bifarray); disp(bifpara)
