% Differential Equations of Circadian Cycle: Symbolic

% DeCaluwe 2016

% 1 = c_{CL}^m;  2 = c_{CL}^p;
% 3 = c_{P97}^m; 4 = c_{P97}^p;
% 5 = c_{P51}^m; 6 = c_{P51}^p;
% 7 = c_{EL}^m;  8 = c_{EL}^p;
% 9 = c_P;

function [dxdt,x] = Circadian_syms_DeCaluwe2016()

    global xsize;

    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);

    v = sym('v', [1 7]); % [v1 v1L v2A v2B v2L v3 v4].
    k = sym('k', [1 5]); % [k1L k1D k2 k3 k4].
    p = sym('p', [1 5]); % [p1 p1L p2 p3 p4].
    d = sym('d', [1 7]); % [d1 d2D d2L d3D d3L d4D d4L].
    K = sym('K', [1 10]);
    syms sun;

    dxdt(1) = (v(1) + v(2) * sun * x(9)) / (1 + (x(4) / K(1))^2 + (x(6) / K(2))^2)...
        - (k(1) * sun + k(2) * (1 - sun)) * x(1);
    dxdt(2) = (p(1) + p(2) * sun) * x(1) - d(1) * x(2);
    dxdt(3) = (v(5) * sun * x(9) + v(3) + v(4) * x(2)^2 / (K(3)^2 + x(2)^2))...
        / (1 + (x(6) / K(4))^2 + (x(8) / K(5))^2) - k(2) * x(3);
    dxdt(4) = p(3) * x(3) - (d(2) * (1 - sun) + d(3) * sun) * x(4);
    dxdt(5) = v(6) / (1 + (x(2) / K(6))^2 + (x(6) / K(7))^2) - k(4) * x(5);
    dxdt(6) = p(4) * x(5) - (d(4) * (1 - sun) + d(5) * sun) * x(6);
    dxdt(7) = sun * v(7) / (1 + (x(2) / K(8))^2 + (x(6) / K(9))^2 + (x(8) / K(10))^2)...
        - k(5) * x(7);
    dxdt(8) = p(4) * x(7) - (d(6) * (1 - sun) + d(7) * sun) * x(8);
    dxdt(9) = 0.3 * (1 - x(9)) * (1 - sun) - x(9) * sun;

end
