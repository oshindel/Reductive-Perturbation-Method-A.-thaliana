% File that runs all the models and makes plots:
% Use the bifurcation parameter that gives the most data points on
% bifurcation diagrams.
tic
global theta mu1 foptions odeopts1;
warning('off','all')

%% Define input values

theta = 1;
mu_min = 0;
mu_max = 0.5;
points = 50; % How many data points I want
controlErr = 0.1;
% Don't set this value too high, say larger than 0.2 - it will not work well.
% If want larger error range, see Grand_LeastDeviateOptimal.m

range = mu_max - mu_min;
step1 = range / points; % step size for simulation.
step2 = step1 / 10; % step size for plotting the fitting curves.
mu1 = mu_min:step1:mu_max;
mu = mu_min:step2:mu_max;

Data_amp = cell(10,1);
Data_freq = cell(10,1);
BP = zeros(10,1);
criticalValues = zeros(10,1);
Omega0 = zeros(10,1);
G = zeros(10,1);
Lambda1 = zeros(10,1);
Omega_s = zeros(10,1);
RR_s = zeros(10,1);

foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);
thetaval = theta;

%% Run all the models and collect data

% Locke 2005a
addpath(genpath('../Code/Locke2005a'))
Main_Locke2005a
Data_amp(1) = {Amplitude};
Data_freq(1) = {Frequency};

BP(1) = bifpara;
criticalValues(1) = criticalval;
Omega0(1) = omega0bif;
G(1) = gbif;
Lambda1(1) = lambda_1;
Omega_s(1) = omegasbif;
RR_s(1) = Rsbif;
rmpath('../Code/Locke2005a')

% Locke 2005b
addpath(genpath('../Code/Locke2005b'))
Main_Locke2005b
Data_amp(2) = {Amplitude};
Data_freq(2) = {Frequency};

BP(2) = bifpara;
criticalValues(2) = criticalval;
Omega0(2) = omega0bif;
G(2) = gbif;
Lambda1(2) = lambda_1;
Omega_s(2) = omegasbif;
RR_s(2) = Rsbif;
rmpath('../Code/Locke2005b')

% Zeilinger 2006
addpath(genpath('../Code/Zeilinger2006'))
Main_Zeilinger2006
Data_amp(3) = {Amplitude};
Data_freq(3) = {Frequency};

BP(3) = bifpara;
criticalValues(3) = criticalval;
Omega0(3) = omega0bif;
G(3) = gbif;
Lambda1(3) = lambda_1;
Omega_s(3) = omegasbif;
RR_s(3) = Rsbif;
rmpath('../Code/Zeilinger2006')

% Pokhilko 2010
addpath(genpath('../Code/Pokhilko2010'))
Main_Pokhilko2010
Data_amp(4) = {Amplitude};
Data_freq(4) = {Frequency};

BP(4) = bifpara;
criticalValues(4) = criticalval;
Omega0(4) = omega0bif;
G(4) = gbif;
Lambda1(4) = lambda_1;
Omega_s(4) = omegasbif;
RR_s(4) = Rsbif;
rmpath('../Code/Pokhilko2010')

% Pokhilko 2012
addpath(genpath('../Code/Pokhilko2012'))
Main_Pokhilko2012
Data_amp(5) = {Amplitude};
Data_freq(5) = {Frequency};

BP(5) = bifpara;
criticalValues(5) = criticalval;
Omega0(5) = omega0bif;
G(5) = gbif;
Lambda1(5) = lambda_1;
Omega_s(5) = omegasbif;
RR_s(5) = Rsbif;
rmpath('../Code/Pokhilko2012')

% Pokhilko 2013
addpath(genpath('../Code/Pokhilko2013'))
Main_Pokhilko2013
Data_amp(6) = {Amplitude};
Data_freq(6) = {Frequency};

BP(6) = bifpara;
criticalValues(6) = criticalval;
Omega0(6) = omega0bif;
G(6) = gbif;
Lambda1(6) = lambda_1;
Omega_s(6) = omegasbif;
RR_s(6) = Rsbif;
rmpath('../Code/Pokhilko2013')

% Fogelmark 2014
addpath(genpath('../Code/Fogelmark2014'))
Main_Fogelmark2014
Data_amp(7) = {Amplitude};
Data_freq(7) = {Frequency};

BP(7) = bifpara;
criticalValues(7) = criticalval;
Omega0(7) = omega0bif;
G(7) = gbif;
Lambda1(7) = lambda_1;
Omega_s(7) = omegasbif;
RR_s(7) = Rsbif;
rmpath('../Code/Fogelmark2014')

% Ohara 2015
addpath(genpath('../Code/Ohara2015'))
Main_Ohara2015
Data_amp(8) = {Amplitude};
Data_freq(8) = {Frequency};

BP(8) = bifpara;
criticalValues(8) = criticalval;
Omega0(8) = omega0bif;
G(8) = gbif;
Lambda1(8) = lambda_1;
Omega_s(8) = omegasbif;
RR_s(8) = Rsbif;
rmpath('../Code/Ohara2015')
theta = thetaval;

% Foo 2016
addpath(genpath('../Code/Foo2016'))
Main_Foo2016
Data_amp(9) = {Amplitude};
Data_freq(9) = {Frequency};

BP(9) = bifpara;
criticalValues(9) = criticalval;
Omega0(9) = omega0bif;
G(9) = gbif;
Lambda1(9) = lambda_1;
Omega_s(9) = omegasbif;
RR_s(9) = Rsbif;
rmpath('../Code/Foo2016')

% De Caluwe 2016
addpath(genpath('../Code/DeCaluwe2016'))
Main_DeCaluwe2016
Data_amp(10) = {Amplitude};
Data_freq(10) = {Frequency};

BP(10) = bifpara;
criticalValues(10) = criticalval;
Omega0(10) = omega0bif;
G(10) = gbif;
Lambda1(10) = lambda_1;
Omega_s(10) = omegasbif;
RR_s(10) = Rsbif;
rmpath('../Code/DeCaluwe2016')

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    ScaledBy REV LEV

%% Figures

mkr = ['o', 's', 'p', '^', 'v', '<', 'd', '+', 'x', '*']; %marker
clr = ['b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b']; %faceColor
eclr = ['n','n','n','n','n','n','n','b','b','b']; %edgeColor
lwth = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 1.5, 1.5, 1]; %lineWidth
siz = [36, 36, 45, 36, 36, 36, 36, 45, 45, 45]; %size

% Amplitude vs. mu
figure(104) % change/delete this number if you already have figure 102 opened
hold on
for i = 1:10
    amp = cell2mat(Data_amp(i));
    scatter(mu1(2:length(amp)),amp(2:end),mkr(i),clr(i),'filled','LineWidth',lwth(i),'MarkerEdgeColor',eclr(i))
end
% for i = 4:10
%     amp = cell2mat(Data_amp(i));
%     scatter(mu1(2:length(amp)),amp(2:end),mkr(i),clr(i))
% end
plot(mu,sqrt(mu),'Color','#D95319','LineWidth',1.5)

% Freqeuncy vs. mu
for i = 1:10
    freq = cell2mat(Data_freq(i));
    scatter(mu1(2:length(freq)),freq(2:end),mkr(i),clr(i),'filled','LineWidth',lwth(i),'MarkerEdgeColor','none')
end
% for i = 4:10
%     freq = cell2mat(Data_freq(i));
%     scatter(mu1(2:length(freq)),freq(2:end),mkr(i),clr(i))
% end
plot(mu,mu,'Color','#D95319','LineWidth',1.5)

% title('LL-cycle') %%%%%%%%%%%%%%%%%%%%%
title('DD-cycle','fontSize',14) %%%%%%%%%%%%%%%%%%%%%
box on
xlabel('\mu','fontSize',14)
ylabel('Scaled Amplitude / Frequency','fontSize',14)
legend('Locke 2005a', 'Locke 2005b', 'Zeilinger 2006',...
    'Pokhilko 2010', 'Pokhilko 2012', 'Pokhilko 2013', 'Fogelmark 2014',...
    'Ohara 2015', 'Foo 2016', 'De Caluwé 2016','Location','SE','fontSize',14)
plottools

toc
