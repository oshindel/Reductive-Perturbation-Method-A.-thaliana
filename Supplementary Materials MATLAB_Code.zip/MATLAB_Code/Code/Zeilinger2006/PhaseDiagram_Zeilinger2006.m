% Zeilinger 2006: Produce Phase Diagrams

clear; clc
load('../../Data/FInalData.mat')
warning('off','all')

global foptions odeopts1...
    xsize...
    nval gval mval pval rval kval qval consv theta...
    critical system var morig index ce X0;

theta = 0;
foptions = optimoptions(@fsolve, 'MaxIterations',1e6, ...
    'MaxFunctionEvaluations', 1e6, 'FunctionTolerance',1e-10,'Display','off');
odeopts1 = odeset('reltol',1e-14);

qval = [13.4334, 7.7786, 1, 6.274];
nval = [3.2016, 11.6086, 2.4751, 1.7832, 7.4615, 11.0924, 0.1031, 3.5262];
gval = [9.041, 16.6598, 13.4112, 20.5277, 1.5987, 16.489, 0.2778, 0.9187, 20.3795, 5.8418];
mval = [6.8248, 9.4099, 13.7795, 12.1232, 7.2129, 9.5754, 1.1032, 2.2006, 4.2193, 8.5523,...
    23.5996, 5.9504, 7.5959, 8.1796, 1.2, 9.3186, 3.6143, 6.7455, 1.9234, 3.7484, 0.0193];
kval = [13.0594, 30.5639, 33.514, 1.3722, 34.2078, 56.7596, 14.9114, 12.528, 15.0626,...
    11.5688, 26.9638, 21.8348, 1.2, 51.261, 32.939, 24.451, 9.8065, 25.9739, 21.6441];
pval = [0.6926, 0.5403, 6.9124, 6.0042, 0.5, 9.8416, 1.5323];
rval = [25.6818, 3.9781, 51.1965, 8.9147, 29.4607, 4.5034, 35.7842, 27.9229,...
    24.5689, 0.5024, 25.7542, 27.2451];
consv = [1.2497, 4.2126, 1.4509, 1.3058, 2.4146, 2.1349, 0, 1.4176, 2.0074,...
    1.7615, 3.8877]; 

morig = mval;

index = [1,2,4,5]; % = [LHY mRNA, LHY protein(c), TOC1 mRNA,TOC1 protein(c)];
xsize = 19; % system size.
modelNum = 3;
[system,var] = Circadian_syms_Zeilinger2006();

bp = BP(modelNum);
scaledby = ScaledBy(modelNum);
R_s = RR_s(modelNum);
omega_s = Omega_s(modelNum);
g = G(modelNum);
gp = real(g);
gpp = imag(g);
omega_0 = Omega0(modelNum);
Ur = REV{modelNum};
Ubr = conj(Ur);
critical = criticalValues(modelNum);

mu_normal = (critical - (morig(bp))) / critical;

%% Generate signals
% ODE

T1 = 1e4;
[~,X] = ode15s(@(t,X)Circadian_Zeilinger2006(t, X, nval, gval, mval,...
        pval, rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = real(X(end,:));

[t,X] = ode15s(@(t,X)Circadian_Zeilinger2006(t, X, nval, gval, mval,...
        pval, rval, kval, qval, consv, theta), [0 T1], X0, odeopts1);
X = real(X);
begin = find(X(:,scaledby) == max(X(:,scaledby)));
t = t(begin(1):end) - t(begin(1));
X = real(X(begin(1):end,:));

% Theory

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

ttheory = (0:0.001:336);
Xtheory = ce' + sqrt(mu_normal)...
    .* (Ur .* R_s .* exp(1i * (omega_0 + (mu_normal) * omega_s) * ttheory)...
    + Ubr .* R_s .* exp(-1i * (omega_0 + (mu_normal) * omega_s) * ttheory));

%% Produce Phase Diagram: LHYm vs LHYc

tpODE = 0:0.1:2*pi;
tp = 0:0.01:2*pi; % t-prime: arbitraty time

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(2)));
deltaPhiODE = -2 * pi * (mean(t(peak2(1:12)) - t(peak1(1:12))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(2)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
LHYcODE = amp2ODE * cos(tpODE + deltaPhiODE);
% relAmpODE = LHYcODE/LHYmODE;

% Theory
U = Ur(index([1 2]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
LHYcTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,LHYcODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,LHYcTheory,'LineWidth',1.5)
axis equal
box on
title('Zeilinger2006 LHYc vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('LHY Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: TOC1m vs TOC1c

% ODE

[max1,peak1] = findpeaks(X(:,index(3)));
[max2,peak2] = findpeaks(X(:,index(4)));
deltaPhiODE = 2 * pi * (mean(t(peak2(1:12)) - t(peak1(1:12))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(3)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(4)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

TOC1mODE = amp1ODE * cos(tpODE);
TOC1cODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([3 4]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1cTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(TOC1mODE,TOC1cODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(TOC1mTheory,TOC1cTheory,'LineWidth',1.5)
axis equal
box on
title('Zeilinger2006 TOC1c vs TOC1m')
xlabel('{\it TOC1} mRNA (nM)')
ylabel('TOC1 Protein (nM)')
legend('ODE','RPM','fontsize',14)
plottools

%% Produce Phase Diagram: LHYm vs TOC1m

% ODE

[max1,peak1] = findpeaks(X(:,index(1)));
[max2,peak2] = findpeaks(X(:,index(3)));
deltaPhiODE = 2 * pi * (mean(t(peak2(1:12)) - t(peak1(1:12))))...
    / (mean([diff(t(peak1));diff(t(peak2))]));
amp1ODE = max1(1) - mean(X(peak1(1):peak1(end),index(1)));
amp2ODE = max2(1) - mean(X(peak1(1):peak1(end),index(3)));
while deltaPhiODE > pi
    deltaPhiODE = deltaPhiODE - 2*pi;
end
while deltaPhiODE < -pi
    deltaPhiODE = deltaPhiODE + 2*pi;
end

LHYmODE = amp1ODE * cos(tpODE);
TOC1mODE = amp2ODE * cos(tpODE + deltaPhiODE);

% Theory
U = Ur(index([1 3]));
a1 = real(U(1));
b1 = imag(U(1));
a2 = real(U(2));
b2 = imag(U(2));

% relAmpTheory = abs(U(2)) / abs(U(1));
deltaPhiTheory  = atan_0to2pi(a2,b2) - atan_0to2pi(a1,b1);
while deltaPhiTheory > pi
    deltaPhiTheory = deltaPhiTheory - 2*pi;
end
while deltaPhiTheory < -pi
    deltaPhiTheory = deltaPhiTheory + 2*pi;
end

LHYmTheory = 2 * R_s * sqrt(mu_normal) * abs(U(1)) * cos(tp);
TOC1mTheory = 2 * R_s * sqrt(mu_normal) * abs(U(2)) * cos(tp + deltaPhiTheory);

% Plotting
figure
hold on
set(gca,'FontSize',14)
scatter(LHYmODE,TOC1mODE,'.','MarkerEdgeColor','b','SizeData',100)
plot(LHYmTheory,TOC1mTheory,'LineWidth',1.5)
axis equal
box on
title('Zeilinger2006 TOC1m vs LHYm')
xlabel('{\it LHY} mRNA (nM)')
ylabel('{\it TOC1} mRNA (nM)')
legend('ODE','RPM','fontsize',14)
plottools


