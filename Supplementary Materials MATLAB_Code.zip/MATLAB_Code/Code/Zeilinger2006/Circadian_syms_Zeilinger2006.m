% Differential Equations of Circadian Cycle: Symbolic

% Zeilinger 2006

% 1 = c_L^m; 2 = c_L^c; 3 = c_L^n;
% 4 = c_T^m; 5 = c_T^c; 6 = c_T^n;
% 7 = c_X^m; 8 = c_X^c; 9 = c_X^n;
% 10 = c_Y^m; 11 = c_Y^c; 12 = c_Y^n;
% 13 = c_P^n;
% 14 = c_{P7}^m; 15 = c_{P7}^c; 16 = c_{P7}^n;
% 17 = c_{P9}^m; 18 = c_{P9}^c; 19 = c_{P9}^n;

function [dxdt,x] = Circadian_syms_Zeilinger2006()

    global xsize;
    x = sym('x', [1 xsize]);
    dxdt = sym('dx', [1 xsize]);
    
    n = sym('n', [1 8]); % n has only 7 elements for PRR7-PRR9_Y model.
    g = sym('g', [1 10]);
    m = sym('m', [1 21]);
    p = sym('p', [1 7]);
    r = sym('r', [1 12]);
    k = sym('k', [1 19]);
    q = sym('q', [1 4]); % q has only 3 elements for PRR7-PRR9_Y model.
    cons = sym('cons', [1 11]);
    syms sun;
    
    dxdt(1) = sun * q(1) * x(13) + (n(1) * x(9)^cons(1) / (g(1)^cons(1) + x(9)^cons(1)))...
        * (g(7)^cons(8) / (g(7)^cons(8) + x(16)^cons(8)))...
        * (g(8)^cons(9) / (g(8)^cons(9) + x(19)^cons(9))) - m(1) * x(1) / (k(1) + x(1));
    dxdt(2) = p(1) * x(1) - r(1) * x(2) + r(3) * x(3) - m(2) * x(2) / (k(2) + x(2));
    dxdt(3) = r(1) * x(2) - r(3) * x(3) - m(3) * x(3) / (k(3) + x(3));
    dxdt(4) = (n(2) * x(12)^cons(2) / (g(2)^cons(2) + x(12)^cons(2)))...
        * (g(3)^cons(3) / (g(3)^cons(3) + x(3)^cons(3)))...
        - m(4) * x(4) / (k(4) + x(4));
    dxdt(5) = p(2) *  x(4) - r(3) * x(5) + r(4) * x(6)...
        - ((1 - sun) * m(5) + m(6)) * x(5) / (k(5) + x(5));
    dxdt(6) = r(3) * x(5) - r(4) * x(6) - ((1 - sun) * m(7) + m(8)) * x(6) / (k(6) + x(6));
    dxdt(7) = n(3) * x(6)^cons(4) / (g(4)^cons(4) + x(4)^cons(4)) - m(9) * x(7) / (k(7) + x(7));
    dxdt(8) = p(3) * x(7) - r(5) * x(8) + r(6) * x(9) - m(10) * x(8) / (k(8)+ x(8));
    dxdt(9) = r(5) * x(8) - r(6) * x(9) - m(11) * x(9) / (k(9)+ x(9));
%     dxdt(10) = (sun * q(2) * x(13) + (sun * n(4) + n(5)) * g(5)^cons(5) / (g(5)^cons(5) + x(6)^cons(5)))...
%          * (g(6)^cons(6) / (g(6)^cons(6) + x(3)^cons(9))) - m(12) * x(10) / (k(10)+ x(10)); % PRR7-PRR9-Y model.
    dxdt(10) = (sun * n(4) + n(5)) * g(5) ^ cons(5) / (g(5)^cons(5) + x(6)^cons(5))...
         * (g(6)^cons(6) / (g(6)^cons(6) + x(3)^cons(9))) - m(12) * x(10) / (k(10)+ x(10)); % PRR7-PRR9light-Y' model.
    dxdt(11) = p(4) * x(10) - r(7) * x(11) + r(8) * x(12) - m(13) * x(11) / (k(11) + x(11));
    dxdt(12) = r(7) * x(11) - r(8) * x(12) - m(14) * x(12) / (k(12) + x(12));
    dxdt(13) = (1 - sun) * p(5) - m(15) * x(13) / (k(13) + x(13)) - q(3) * sun * x(13);
    dxdt(14) = n(6) * x(3)^cons(10) / (g(9)^cons(10) + x(3)^cons(10))- m(16) * x(14) / (k(14) + x(14));
    dxdt(15) = p(6) * x(14) - r(9) * x(15) + r(10) * x(16) - m(17) * x(15) / (k(15) + x(15));
    dxdt(16) = r(9) * x(15) - r(10) * x(16) - m(18) * x(16) / (k(16) + x(16));
%     dxdt(17) = n(7) * x(3)^cons(11) / (g(10)^cons(11) + x(3)^cons(11)) - m(19) * x(17) / (k(17) + x(17)); % PRR7-PRR9-Y model.
    dxdt(17) = (sun * q(4) * x(13) + sun * n(7) + n(8)) * x(3)^cons(11) / (g(10)^cons(11) + x(3)^cons(11))...
         - m(19) * x(17) / (k(17) + x(17)); % PRR7-PRR9light-Y model.
    dxdt(18) = p(7) * x(17) - r(11) * x(18) + r(12) * x(19) - m(20) * x(18) / (k(18) + x(18));
    dxdt(19) = r(11) * x(18) - r(12) * x(19) - m(21) * x(19) / (k(19) + x(19));
    
end
