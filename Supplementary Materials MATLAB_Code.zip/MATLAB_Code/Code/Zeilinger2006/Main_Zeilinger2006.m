% Main file for simulation: Zeilinger 2006

clearvars -except mu1 mu Data_amp Data_freq...
    BP criticalValues Omega0 G Lambda1 Omega_s RR_s...
    theta foptions odeopts1 controlErr...
    REV LEV ScaledBy

global foptions odeopts1...
    xsize kb...
    nval gval mval pval rval kval qval consv mk...
    critical system var morig index ce X0;

%% Import Parameter Values

xsize = 19; % system size.

qval = [13.4334, 7.7786, 1, 6.274];
nval = [3.2016, 11.6086, 2.4751, 1.7832, 7.4615, 11.0924, 0.1031, 3.5262];
gval = [9.041, 16.6598, 13.4112, 20.5277, 1.5987, 16.489, 0.2778, 0.9187, 20.3795, 5.8418];
mval = [6.8248, 9.4099, 13.7795, 12.1232, 7.2129, 9.5754, 1.1032, 2.2006, 4.2193, 8.5523,...
    23.5996, 5.9504, 7.5959, 8.1796, 1.2, 9.3186, 3.6143, 6.7455, 1.9234, 3.7484, 0.0193];
kval = [13.0594, 30.5639, 33.514, 1.3722, 34.2078, 56.7596, 14.9114, 12.528, 15.0626,...
    11.5688, 26.9638, 21.8348, 1.2, 51.261, 32.939, 24.451, 9.8065, 25.9739, 21.6441];
pval = [0.6926, 0.5403, 6.9124, 6.0042, 0.5, 9.8416, 1.5323];
rval = [25.6818, 3.9781, 51.1965, 8.9147, 29.4607, 4.5034, 35.7842, 27.9229,...
    24.5689, 0.5024, 25.7542, 27.2451];
consv = [1.2497, 4.2126, 1.4509, 1.3058, 2.4146, 2.1349, 0, 1.4176, 2.0074,...
    1.7615, 3.8877]; 

morig = mval;
disp('Zeilinger 2006')

%% Generate Essential Matrices and Values

% Generate system and Jacobian
[system,var] = Circadian_syms_Zeilinger2006();
Jacobian();

% Set initial values for fsolve and ode solver
T1 = 1e5;
[~,X] = ode15s(@(t,X)Circadian_Zeilinger2006(t, X, nval, gval, mval,...
        pval, rval, kval, qval, consv, theta), [0 T1], ones(1,xsize), odeopts1);
X0 = X(end,:);

System = Evaluation(system);
systemFunc = matlabFunction(System,'Vars',{var});
[ce,~] = fsolve(systemFunc,X0,foptions);

%% Bifurcation Parameters & Calculate Critical Values and Eigenvalues

[ideg, crit] = Filter();
[sigma1s, omega1s] = Calc_sigma_omega(ideg, crit);

%% Select Parameter & Generate Data

Amplitude = [];
Frequency = [];
jmax = 0;

T2 = 1e4;
for i = 1:length(ideg)
    
    mval = morig;
    kb = ideg(i);
    disp(kb)
    critical = crit(i);
    sigma_1 = sigma1s(i);
    omega_1 = omega1s(i);
    mk = morig(kb); % optimal value of bifurcation parameter.

    %% Find the index of largest amplitude

    mval(kb) = critical - critical * mu1(2);
    [~,X] = ode15s(@(t,X)Circadian_Zeilinger2006(t, X, nval, gval, mval,...
            pval, rval, kval, qval, consv, theta), [0 T2], X0, odeopts1);
    X0 = X(end,:);

    Amp = 1/2 * (max(X(round(end/2):end,:)) - min(X(round(end/2):end,:)));
    [Amp,ind] = sort(Amp);
    index = ind(end);

    %% Calculate Stuart-Landau Parameters
    
    [g, omega_0] = Generate_values();
    gp = real(g); % g-prime.
    gpp = imag(g); % g-double-prime.

    R_s = sqrt(critical) * sqrt(abs(sigma_1 / abs(gp)));
    omega_s = critical * (omega_1 - sigma_1 * gpp/gp);

    %% ODE Solver Simulation

    Simulate_Circadian_Zeilinger2006
    if j > jmax
        jmax = j;
        Amplitude = amplitude;
        Frequency = frequency;
        omega0bif = omega_0;
        gbif = g;
        lambda_1 = sigma_1 + 1i * omega_1;
        omegasbif = omega_s;
        Rsbif = R_s;
        bifpara = kb;
        criticalval = critical;
    end
    
end
disp('Bifurcation parameter:'); disp(bifpara)
