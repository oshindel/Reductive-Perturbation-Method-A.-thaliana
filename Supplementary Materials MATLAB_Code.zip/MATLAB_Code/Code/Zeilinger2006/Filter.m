% Filter the degradation rates that lead to bifurcation
% between 0 and optimal value
% and create array with corresponding critical values

% idegradation1 returns the indices of degradation rates that satisfy the critiria;
% critical_values1 gives the critical value of those degradation rates.

function [idegradation, critical_values] = Filter()

    global mval morig
    
    idegradation = [];
    critical_values = [];
    ideg = 1;
    
    for i = 1:length(mval)
        disp(i)
        mval = morig;
        if mval(i) == 0
            continue
        end
        
        [lambda, ~] = Calc_lambdas();
        if real(lambda) > 0 % supercritical
            increment = 0.1;
            if morig(i) > 15
                bound = morig(i) * [1 2];
            elseif morig(i) < 1
                bound = morig(i) * [1 10];
            else
                bound = morig(i) * [1 5];
            end
            sgn = 1;
        elseif real(lambda) < 0 % subcritical
            increment = - 0.1;
            bound = morig(i) * [1/3 1];
            sgn = -1;
        end
        
        inrange = 1;
        mval(i) = mval(i) + increment;
        while sign(real(lambda)) == sgn && inrange
            [lambda, ~] = Calc_lambdas();
            mval(i) = mval(i) + increment;
            inrange = mval(i) > bound(1) && mval(i) < bound(2);
        end
        
        if ~(sign(real(lambda)) == sgn)
            idegradation(ideg) = i;
            range = sort([mval(i),mval(i) - 2*increment]);
            critical_values(ideg) = Solve_cp(range,i);
            ideg = ideg + 1;
        end
    end
    disp('Potential bifurcation parameters:');
    disp(idegradation)
    
end
